//
//  SpeechTestView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/30/25.
//
import SwiftUI
import AVFoundation

struct VoiceTestView: View {
    @State private var selectedVoice: AVSpeechSynthesisVoice? = AVSpeechSynthesisVoice.speechVoices().first
    @State private var message: String = "You're leaning left. Center up!"
    @State private var intensity: Int = 3

    private let synthesizer = AVSpeechSynthesizer()

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Message")) {
                    TextField("Message", text: $message)
                }

                Section(header: Text("Intensity Level")) {
                    Picker("Intensity", selection: $intensity) {
                        ForEach(1..<6) { level in
                            Text("\(level)")
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }

                Section(header: Text("Voice")) {
                    Picker("Voice", selection: $selectedVoice) {
                        ForEach(AVSpeechSynthesisVoice.speechVoices(), id: \ .identifier) { voice in
                            Text(voice.name + " (" + voice.language + ")")
                                .tag(voice as AVSpeechSynthesisVoice?)
                        }
                    }
                }

                Button("Speak") {
                    speak(message: message, intensity: intensity, voice: selectedVoice)
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .navigationTitle("Voice Test")
        }
    }

    private func speak(message: String, intensity: Int, voice: AVSpeechSynthesisVoice?) {
        let utterance = AVSpeechUtterance(string: message)
        utterance.voice = voice ?? AVSpeechSynthesisVoice(language: "en-US")

        // Adjust rate and pitch based on intensity
        switch intensity {
        case 1:
            utterance.rate = 0.4
            utterance.pitchMultiplier = 0.9
        case 2:
            utterance.rate = 0.45
            utterance.pitchMultiplier = 1.0
        case 3:
            utterance.rate = 0.5
            utterance.pitchMultiplier = 1.1
        case 4:
            utterance.rate = 0.55
            utterance.pitchMultiplier = 1.2
        case 5:
            utterance.rate = 0.6
            utterance.pitchMultiplier = 1.3
        default:
            break
        }

        utterance.volume = 1.0
        synthesizer.speak(utterance)
    }
}

#Preview {
    VoiceTestView()
}
