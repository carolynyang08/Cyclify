//
//  CyclifyApp.swift
//  Cyclify
//
//  Created by Carolyn Yang on 2/24/25.
//

import SwiftUI
import SwiftData

@main
struct CyclifyApp: App {
    @StateObject var bluetoothManager = BluetoothManager()
    @StateObject var calibrationModel = CalibrationModel()

    
    init() {
//        let rideModel = RideModel()
//        _rideModel = StateObject(wrappedValue: rideModel)
//        _bluetoothManager = StateObject(wrappedValue: BluetoothManager(rideModel:rideModel))
        
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .black
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
        UINavigationBar.appearance().tintColor = .white
    }
    
    var body: some Scene {
           WindowGroup {
               AppEntryPointView(
                   bluetoothManager: bluetoothManager,
                   calibrationModel: calibrationModel
               )
           }
           .modelContainer(for: [UserModel.self, Ride.self, SensorReading.self])
       }
    
//    var body: some Scene {
//        WindowGroup {
//            if userModel.isLoggedIn {
//                MainTabView(
//                    userModel: userModel,
//                    bluetoothManager: bluetoothManager,
//                    calibrationModel: calibrationModel,
//                    rideModel: rideModel
//                )
//            } else {
//                WelcomeView(
//                    userModel: userModel,
//                    bluetoothManager: bluetoothManager,
//                    calibrationModel: calibrationModel,
//                    rideModel: rideModel
//                )
//            }
//        }
//        .modelContainer([UserModel.self, Ride.self, SensorReading.self])
//    }
    
}

