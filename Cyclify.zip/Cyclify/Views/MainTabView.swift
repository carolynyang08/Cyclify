//
//  MainTabView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/29/25.
//

import SwiftUI
import SwiftData

struct MainTabView: View {
//    @ObservedObject var userModel: UserModel
    @ObservedObject var bluetoothManager: BluetoothManager
    @ObservedObject var calibrationModel: CalibrationModel
//    @ObservedObject var rideModel: RideModel
//    

    var body: some View {
        TabView {
            MainView(bluetoothManager: bluetoothManager, calibrationModel: calibrationModel)
//            VoiceTestView()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }

            RecordView(bluetoothManager: bluetoothManager)
                .tabItem {
                    Image(systemName: "record.circle")
                    Text("Record")
                }

            ProfileView()
                .tabItem {
                    Image(systemName: "person")
                    Text("You")
                }
        }
        .accentColor(.white)
    }
}


struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        let user = UserModel(
            email: "preview@example.com",
            firstName: "Preview",
            lastName: "User",
            weight: 160,
            weightUnit: "LB",
            heightFeet: 5,
            heightInches: 11
        )

        let container = try! ModelContainer(
            for: UserModel.self, Ride.self, SensorReading.self,
            configurations: ModelConfiguration(isStoredInMemoryOnly: true)
        )

        container.mainContext.insert(user)

        return NavigationStack {
            MainTabView(
                bluetoothManager: BluetoothManager(),
                calibrationModel: CalibrationModel()
            )
        }
        .modelContainer(container)
    }
}
