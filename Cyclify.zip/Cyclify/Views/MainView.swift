//
//  MainView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/23/25.
//

import SwiftUI
import SwiftData

struct MainView: View {
    @Query(filter: #Predicate<UserModel> { user in
        user.isLoggedIn == true
    }) private var users: [UserModel]

    @Environment(\.modelContext) private var modelContext
//    @Query private var users: [UserModel]
    @ObservedObject var bluetoothManager: BluetoothManager
    @ObservedObject var calibrationModel: CalibrationModel
    
    
    @State private var showingCalibration = false
    @Query private var rides: [Ride]
    
    let customBlue = Color(red: 8 / 255, green: 196 / 255, blue: 252 / 255)
    let customSky = Color(red: 99 / 255.0, green: 197 / 255.0, blue: 218 / 255.0)
    let customLavender = Color(red: 184 / 255.0, green: 180 / 255.0, blue: 244 / 255.0)


    
    
    var currentUser: UserModel? {
        users.first
    }
    
    var todayRide: Ride? {
        let calendar = Calendar.current
        return currentUser?.rides
            .filter { calendar.isDateInToday($0.startTime) }
            .sorted(by: { $0.startTime > $1.startTime })
            .first
    }
    
    var weeklyDuration: TimeInterval {
        let calendar = Calendar.current
        let startOfWeek = calendar.date(from: calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date())) ?? Date()
        let thisWeekRides = currentUser?.rides.filter { $0.startTime >= startOfWeek } ?? []
        return thisWeekRides.reduce(0) { $0 + $1.duration }
    }


    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Hi, \(currentUser?.firstName ?? "Cyclist")")
                        .font(.title)
                        .fontWeight(.bold)

                    Text("Let’s go for a ride.")
                        .font(.subheadline)
                        .foregroundColor(.white)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 25)
                

        Group {
         if let ride = todayRide {
             NavigationLink(destination: RideDetailView(ride: ride)) {
                 HStack {
                     VStack(alignment: .leading, spacing: 30) {
                         Text("Today’s Ride")
                             .font(.title)
                             .fontWeight(.bold)

                         Text("View Activity")
                             .font(.headline)
                             .padding(8)
                             .background(LinearGradient(colors: [Color.blue, Color.purple], startPoint: .leading, endPoint: .trailing))
                             .foregroundColor(.white)
                             .cornerRadius(10)
                     }
                     Spacer()
                     Image(systemName: "bicycle")
                         .resizable()
                         .frame(width: 100, height: 75)
                         .foregroundColor(.white)
                 }
                 .padding()
                 .background(customBlue)
                 .cornerRadius(20)
                 .padding(.horizontal)
             }
         } else {
             HStack {
                 VStack(alignment: .leading, spacing: 30) {
                     Text("Today’s Ride")
                         .font(.title)
                         .fontWeight(.bold)

                     Text("Your workout log is empty today.")
                         .font(.headline)
                         .foregroundColor(.white)
                 }
                 Spacer()
                 Image(systemName: "bicycle")
                     .resizable()
                     .frame(width: 100, height: 75)
                     .foregroundColor(.white)
             }
             .padding()
             .background(customBlue)
             .cornerRadius(20)
             .padding(.horizontal)
         }
     }
        
                Text("This Week")
                    .font(.title3)
                    .fontWeight(.bold)
                    .padding(.top)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 20)
                
                HStack(spacing: 16) {
                VStack {
                    Text("Form Improvement")
                        .font(.caption)
                        .fontWeight(.bold)
                    Text("+5")
                        .font(.title2)
                        .fontWeight(.bold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(customSky)
                .cornerRadius(10)

                VStack {
                    Text("Duration")
                        .font(.caption)
                        .fontWeight(.bold)
                    Text(formattedDuration(from: weeklyDuration))
                        .font(.title2)
                        .fontWeight(.bold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(customSky)
                .cornerRadius(10)
            }
            .padding(.horizontal)
                
                Text("Personalized Ride Tips")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.top, 15)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)

                VStack(alignment: .leading, spacing: 10) {
                    Text("• Weight Distribution Adjustment\nYour left leg is doing less work—shift some effort there to keep your ride smooth.")
                        .font(.subheadline)
                        .fontWeight(.bold)
                    Text("• Heart Rate Feedback\nWhen your heart rate is high, your form starts to break down—consider easing up a bit to maintain good technique.")
                        .font(.subheadline)
                        .fontWeight(.bold)
                }
                .padding()
                .background(customLavender)
                .cornerRadius(10)
                .padding(.horizontal)
                
                Spacer()
                
                Button(action: {
                    showingCalibration = true
                }) {
                    Text("Calibrate")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(customBlue)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                }
                .padding(.horizontal)
                
                //                Button(action: {
                //                    userModel.reset()
                //                }) {
                //                    Text("Logout")
                //                        .font(.headline)
                //                        .frame(maxWidth: .infinity)
                //                        .padding()
                //                        .background(Color.red)
                //                        .foregroundColor(.white)
                //                        .cornerRadius(10)
                //                }
                //                .padding(.horizontal)
                //                .padding(.bottom)
            }
            .padding(.top)
            .background(Color.black.edgesIgnoringSafeArea(.all))
            .foregroundColor(.white)
            .preferredColorScheme(.dark)
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading:
                Menu {
                    Button("Logout", role: .destructive) {
                        logout()
                    }
                   } label: {
                       Image(systemName: "line.horizontal.3")
                           .resizable()
                           .frame(width: 24, height: 18)
                           .foregroundColor(.white)
                           .padding(.leading)
                   }
               )
            .fullScreenCover(isPresented: $showingCalibration) {
                           NavigationStack {
                               if let user = currentUser {
                                   CalibrationIntroView(
                                       userModel: user,
                                       bluetoothManager: bluetoothManager,
                                       calibrationModel: calibrationModel
                                   )
                               }
                }
            }
        }
    }
    
    private func formattedDuration(from seconds: TimeInterval) -> String {
            let formatter = DateComponentsFormatter()
            formatter.allowedUnits = [.hour, .minute]
            formatter.unitsStyle = .abbreviated
            return formatter.string(from: seconds) ?? "0m"
        }
    
    private func logout() {
        if let user = users.first(where: { $0.isLoggedIn }) {
            user.isLoggedIn = false
            do {
                try modelContext.save()
                print("User logged out")
            } catch {
                print("Failed to save logout: \(error)")
            }
        }
    }

}





struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        let container = try! ModelContainer(for: UserModel.self, Ride.self, SensorReading.self)
        let context = container.mainContext

        // Optional: insert a test user
        let mockUser = UserModel(
            email: "preview@example.com",
            firstName: "Preview",
            lastName: "User",
            weight: 150,
            weightUnit: "LB",
            heightFeet: 5,
            heightInches: 10
        )
        context.insert(mockUser)

        return MainView(
            bluetoothManager: BluetoothManager(),
            calibrationModel: CalibrationModel()
        )
        .modelContainer(container)
    }
}
