//
//  RecordView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/29/25.
//

import SwiftUI
import SwiftData

struct RecordView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var users:[UserModel]
//    @ObservedObject var userModel: UserModel
    @ObservedObject var bluetoothManager: BluetoothManager
//    @ObservedObject var rideModel: RideModel

    @State private var currentRide: Ride? = nil
    @State private var isRiding = false
    let customCyan = Color(red: 145 / 255, green: 255 / 255, blue: 255 / 255)

    var currentUser: UserModel? {
        users.first
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 30) {
                Text("Get Ready to Ride!")
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 15)
                    .foregroundColor(customCyan)
                    .padding(.top, 40)

                Image("lean-left") // Replace with your actual image name
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300)
                    .cornerRadius(16)

                Spacer().frame(height: 30)

                Text("Ensure proper setup for a seamless ride")
                    .font(.title3)
                    .foregroundColor(.white)
                    .padding(.bottom, 40)

                Button(action: {
                    isRiding.toggle()

                    if isRiding {
                        let newRide = Ride(startTime: Date())
                        print("Ride started — currentRide ID: \(newRide.id)")

                        if let user = currentUser {
                            user.rides.append(newRide)
                            newRide.user = user
                        }

                        modelContext.insert(newRide)
                        bluetoothManager.currentRide = newRide
                        bluetoothManager.modelContext = modelContext
                        currentRide = newRide

                        try? modelContext.save()
                        
                        bluetoothManager.startRide()
                        bluetoothManager.sendRideControl("START")
                        

                    } else {
                        bluetoothManager.stopRide()
                        bluetoothManager.sendRideControl("STOP")
                        currentRide?.endTime = Date()

                        if let ride = currentRide {
                            print("Buffered Sensor Readings:")
                            for reading in bluetoothManager.bufferedReadings {
                                print("\(reading.timestamp): \(reading.sensors)")
                                reading.ride = ride
                                ride.sensorData.append(reading)
                                modelContext.insert(reading)
                            }
                            
                            print("Buffered Alert Readings:")
                            for alert in bluetoothManager.bufferedAlerts {
                                alert.ride = ride
                                ride.alerts.append(alert)
                                modelContext.insert(alert)
                                
                            }

                            do {
                                try modelContext.save()
                                print("Saved \(bluetoothManager.bufferedReadings.count) readings to database")
                                print("Saved \(bluetoothManager.bufferedAlerts.count) alerts to database")
                            } catch {
                                print("Failed to save readings: \(error)")
                                print("Failed to save alerts: \(error)")               }

                            bluetoothManager.bufferedReadings.removeAll()
                            bluetoothManager.bufferedAlerts.removeAll()
                        }

                        currentRide = nil
                    }
                })
{
                    ZStack {
                        Circle()
                            .fill(customCyan)
                            .frame(width: 100, height: 100)

                        VStack {
                            Image(systemName: isRiding ? "stop.fill" : "play.fill")
                                .foregroundColor(.white)
                                .font(.system(size: 24, weight: .bold))
                            Text(isRiding ? "FINISH" : "START")
                                .foregroundColor(.white)
                                .font(.footnote)
                                .fontWeight(.bold)
                        }
                    }
                }

                Spacer()
            }
        }
    }
}

#Preview {
    RecordView(bluetoothManager: BluetoothManager())
}


