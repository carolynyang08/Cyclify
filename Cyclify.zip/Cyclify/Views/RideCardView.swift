//
//  RideCardView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/29/25.
//

import SwiftUI
import SwiftData
import Charts

struct RideCardView: View {
    let ride: Ride
    let customCyan = Color(red: 145 / 255, green: 255 / 255, blue: 255 / 255)
    let customBlue = Color(red: 8 / 255, green: 196 / 255, blue: 252 / 255)
    
    
    var body: some View {
        NavigationLink(destination: RideDetailView(ride: ride)) {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Image(systemName: "bicycle")
                    Text("Cycle")
                        .fontWeight(.semibold)
                    Circle()
                        .frame(width: 6, height: 6)
                    Text(ride.formattedStartTime)
                        .font(.subheadline)
                        .bold()
                }

                HStack(spacing: 20){
                    VStack(alignment: .leading) {
                        Text("Time")
                            .font(.caption)
                        Text(ride.formattedDuration)
                            .bold()
                    }
                    Spacer()
                    VStack(alignment: .leading) {
                        Text("Avg HR")
                            .font(.caption)
                        Text("\(ride.averageHeartRate ?? 0) bpm")
                            .bold()
                    }
                    Spacer()
                    VStack(alignment: .leading) {
                        Text("Cal")
                            .font(.caption)
                        Text("\(ride.caloriesBurned ?? 0) cal")
                            .bold()
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                }
            }
            .foregroundColor(customBlue)
            .padding()
            .background(customCyan)
            .cornerRadius(18)
            .padding(.horizontal, 10)
        }
    }
}

struct RideDetailView: View {
    @Environment(\.modelContext) private var modelContext
    
    @State private var sensorReadings: [SensorReading] = []
    @State private var rideAlerts: [RideAlert] = []
    
    let ride: Ride
    let customCyan = Color(red: 145 / 255, green: 255 / 255, blue: 255 / 255)
    let customBlue = Color(red: 8 / 255, green: 196 / 255, blue: 252 / 255)
    let customLavender = Color(red: 184 / 255.0, green: 180 / 255.0, blue: 244 / 255.0)
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Morning Ride")
                    .font(.largeTitle)
                    .bold()
                
                Text(ride.formattedStartTime)
                    .font(.subheadline)
                
                HStack {
                    VStack {
                        Text("Elapsed Time")
                            .font(.caption)
                            .fontWeight(.bold)
                        Text(ride.formattedDuration)
                            .bold()
                    }
                    Spacer()
                    VStack {
                        Text("Avg Heart Rate")
                            .font(.caption)
                            .fontWeight(.bold)
                        Text("\(ride.averageHeartRate ?? 0) bpm")
                            .bold()
                    }
                    Spacer()
                    VStack {
                        Text("Calories")
                            .fontWeight(.bold)
                            .font(.caption)
                        Text("\(ride.caloriesBurned ?? 0)")
                            .bold()
                    }
                }
                .padding()
                .background(customBlue)
                .cornerRadius(10)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Form Analytics")
                        .font(.title3)
                        .bold()
                    
                    if sensorReadings.isEmpty {
                        Text("No sensor data available.")
                            .foregroundColor(.gray)
                    } else {
                        let sortedData = sensorReadings.sorted(by: { $0.timestamp < $1.timestamp })
                        
                        Chart {
                            ForEach(sortedData, id: \ .timestamp) { reading in
                                ForEach(reading.sensors.indices, id: \ .self) { index in
                                    LineMark(
                                        x: .value("Time", reading.timestamp),
                                        y: .value("Sensor", reading.sensors[index])
                                    )
                                    .foregroundStyle(by: .value("Sensor", "Sensor \(index + 1)"))
                                }
                            }
                        }
                        .frame(height: 250)
                        .chartYAxisLabel("Sensor Value")
                        .chartXAxisLabel("Time")
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Form Violations")
                        .font(.title3)
                        .bold()

                    if rideAlerts.isEmpty {
                        Text("No form alerts available.")
                            .foregroundColor(.gray)
                    } else {
                        AlertBarChart(alerts: rideAlerts)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
                
//                RideAlertFreqChart()

            }
            .padding()
        }
        .navigationTitle("Activities")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            loadSensorData()
            loadAlerts()
        }
    }
    
    private func loadSensorData() {
        let fetchRequest = FetchDescriptor<SensorReading>()

        do {
            let allReadings = try modelContext.fetch(fetchRequest)
            sensorReadings = allReadings.filter { $0.ride?.id == ride.id }

            print("Loaded \(sensorReadings.count) readings for ride \(ride.id)")
            for reading in sensorReadings {
                print("\(reading.timestamp): \(reading.sensors)")
            }
        } catch {
            print("Failed to load sensor readings: \(error)")
        }
    }
    
    private func loadAlerts() {
        let fetchRequest = FetchDescriptor<RideAlert>()

        do {
            let allAlerts = try modelContext.fetch(fetchRequest)
            rideAlerts = allAlerts.filter { $0.ride?.id == ride.id }

            print("Loaded \(rideAlerts.count) alerts for ride \(ride.id)")
            for alert in rideAlerts {
                print("\(alert.timestamp): Type \(alert.type), Intensity \(alert.intensity)")
            }
        } catch {
            print("Failed to load ride alerts: \(error)")
        }
    }
}

//private func groupedAlertCounts(interval: TimeInterval = 10.0) -> [(time: Double, count: Int)] {
//    let grouped = Dictionary(grouping: rideAlerts) { alert in
//        floor(alert.timestamp / interval) * interval
//    }
//    return grouped.map { (time, alerts) in
//        (time: time, count: alerts.count)
//    }
//    .sorted { $0.time < $1.time }
//}
//
//private struct RideAlertFreqChart: View{
//    let alerts: [RideAlert]
//    
////    VStack(alignment: .leading, spacing: 12) {
////        Text("Alert Frequency Over Time")
////            .font(.title3)
////            .bold()
//    var body: some View {
//        let alertFrequency = groupedAlertCounts(interval: 10)
//        
//    }
//        

      
//          
//}

private struct AlertBarChart: View {
    let alerts: [RideAlert]
    let customCyan = Color(red: 145 / 255, green: 255 / 255, blue: 255 / 255)
    let customBlue = Color(red: 8 / 255, green: 196 / 255, blue: 252 / 255)
    let customLavender = Color(red: 184 / 255.0, green: 180 / 255.0, blue: 244 / 255.0)
    let customPurple = Color(red: 204 / 255, green: 136 / 255, blue: 153 / 255)

    var body: some View {
        let alertCounts = Dictionary(grouping: alerts, by: { $0.type })
            .mapValues { $0.count }

        Chart {
            ForEach(alertCounts.sorted(by: { $0.key < $1.key }), id: \.key) { (type, count) in
                BarMark(
                    x: .value("Violation Type", "Type \(type)"),
                    y: .value("Count", count)
                )
                .foregroundStyle(by: .value("Violation Type", "Type \(type)"))
            }
        }
        .frame(height: 250)
        .chartYAxisLabel("Frequency")
        .chartXAxisLabel("Violation Type")
        .chartForegroundStyleScale([
                   "Type 1": customLavender,
                   "Type 2": customPurple,
                   "Type 3": customCyan,
                   "Type 4": customBlue
               ])
    }
}



//                    VStack(alignment: .leading, spacing: 12) {
//                        Text("Form Violations")
//                            .font(.title3)
//                            .bold()
//
//                        if rideAlerts.isEmpty {
//                            Text("No form alerts available.")
//                                .foregroundColor(.gray)
//                        } else {
//                            // Count alerts per type
//                            let alertCounts = Dictionary(grouping: rideAlerts, by: { $0.alertType })
//                                .mapValues { $0.count }
//
//                            Chart {
//                                ForEach(alertCounts.sorted(by: { $0.key < $0.key }), id: \.key) { (type, count) in
//                                    BarMark(
//                                        x: .value("Violation Type", "Type \(type)"),
//                                        y: .value("Count", count)
//                                    )
//                                    .foregroundStyle(.blue)
//                                }
//                            }
//                            .frame(height: 250)
//                            .chartYAxisLabel("Frequency")
//                            .chartXAxisLabel("Violation Type")
//                        }
//                    }
//                    .padding()
//                    .background(Color.gray.opacity(0.2))
//                    .cornerRadius(10)
