//
//  Calibrate3.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/28/25.
//

import SwiftUI

struct Calibrate3: View {
    var userModel: UserModel
    @ObservedObject var bluetoothManager: BluetoothManager
    @ObservedObject var calibrationModel: CalibrationModel
    
    @Environment(\.presentationMode) var presentationMode
    
    // State for managing the calibration process
    @State private var isCalibrating = false
    @State private var forceReadings: [[Int]] = [] // Store force readings as an array of arrays
    @State private var timer: Timer? = nil
    @State private var elapsedTime: Int = 0
    @State private var countdownValue: Int? = nil
    @State private var navigateToNext: Bool = false

    
    // Custom gradient colors (same as previous views)
    let lightBlue = Color(red: 0.0, green: 0.67, blue: 1.0)
    let darkPurple = Color(red: 0.5, green: 0.0, blue: 1.0)
    
    // Computed property to determine the button label
    private var buttonLabel: String {
        if isCalibrating {
            return "Calibrating..."
        } else if elapsedTime >= 10 {
            return "Next"
        } else {
            return "Start"
        }
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                Color.black.edgesIgnoringSafeArea(.all)
                
                Image("cyclify-bike")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250, height: 250)
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [lightBlue, darkPurple]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .position(x: 40, y: 60)
                
                // Bike image in bottom-right corner
                Image("cyclify-bike")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250, height: 250)
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [lightBlue, darkPurple]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .position(x: geometry.size.width - 30, y: geometry.size.height - 150)
                
                
                // Main content
                VStack {
                    Spacer().frame(height: 60)
                    
                    // Title
                    Text("Posture Calibration: Lean Forward")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .lineLimit(nil)
                        .padding(.bottom, 10)
                        .padding(.horizontal, 30)
                    
                    // Instructional text
                    Text("Hold this position while we capture your posture data.")
                        .font(.title3)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                        .padding(.bottom, 20)
                        .lineLimit(nil)
                    
                    // Image of cyclist leaning left
                    Image("lean-left") // Replace with your actual image name
                        .resizable()
                        .scaledToFit()
                        .frame(width: geometry.size.width - 80, height: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .padding(.bottom, 20)
                    
//                    // Display force readings
//                    if isCalibrating || !forceReadings.isEmpty {
//                        Text(isCalibrating ? "\(10 - elapsedTime) seconds remaining" : "Calibration Complete")
//                            .font(.title3)
//                            .foregroundColor(.white)
//                            .padding(.bottom, 10)
//
//                        ScrollView {
//                            VStack(alignment: .leading) {
//                                ForEach(Array(calibrationModel.getReadings(for: .leanRight).enumerated()), id: \.offset) { index, readings in
//                                    Text("Reading \(index + 1): \(readings.map { "\($0)" }.joined(separator: ", ")) N")
//                                        .foregroundColor(.white)
//                                        .font(.body)
//                                }
//                            }
//                        }
//                        .frame(height: 100)
//                        .padding(.horizontal, 40)
//
//                    }
                    
                    if !calibrationModel.getReadings(for: .leanRight).isEmpty {
                        Text(isCalibrating ? "\(10 - elapsedTime) seconds remaining" : "Calibration Complete")
                            .font(.title3)
                            .foregroundColor(.white)
                            .padding(.bottom, 10)

                        ScrollView {
                            VStack(alignment: .leading) {
                                ForEach(Array(calibrationModel.getReadings(for: .leanRight).enumerated()), id: \.offset) { index, readings in
                                    Text("Reading \(index + 1): \(readings.map { "\($0)" }.joined(separator: ", ")) N")
                                        .foregroundColor(.white)
                                        .font(.body)
                                }
                            }
                        }
                        .frame(height: 150)
                        .padding(.horizontal, 40)
                    }

                    
                    Spacer()
                    
                    // Redo button
//                    Button(action: {
//                        startCalibration()
//                    }) {
//                        HStack {
//                            Image(systemName: "arrow.counterclockwise")
//                                .foregroundColor(.white)
//                            Text("Redo")
//                                .font(.headline)
//                                .foregroundColor(.white)
//                        }
//                    }
//                    .padding(.bottom, 10)
//                    .disabled(isCalibrating) // Disable during calibration
                    
                    if let countdown = countdownValue {
                        Text("Starting in \(countdown)")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding(.bottom, 10)
                            .transition(.opacity)
                    } else {
                        Button(action: {
                            startCalibration()
                        }) {
                            HStack {
                                Image(systemName: "arrow.counterclockwise")
                                    .foregroundColor(.white)
                                Text("Redo")
                                    .font(.headline)
                                    .foregroundColor(.white)
                            }
                        }
                        .padding(.bottom, 10)
                        .disabled(isCalibrating)
                    }

                    
                    
                    // Start/Next button with NavigationLink
                    
                    
                    NavigationLink(
                        destination: Calibrate4(userModel: userModel, bluetoothManager: bluetoothManager, calibrationModel: calibrationModel),
                        isActive: $navigateToNext
                    ) {
                        Button(action: {
                            if !isCalibrating && elapsedTime >= 10 {
                                navigateToNext = true
                            } else if !isCalibrating {
                                startCalibration()
                            }
                            // If elapsedTime >= 10, the NavigationLink will handle navigation
                        }) {
                            ZStack {
                                if isCalibrating {
                                    GradientProgressBar(progress: Double(elapsedTime)/10.0)
                                        .frame(width: 150, height: 12)
                                        .clipShape(Capsule())
                                } else if countdownValue == nil {
                                    Text(elapsedTime >= 10 ? "Next" : "Start")
                                        .font(.headline)
                                        .frame(width: 150, height:50)
                                        .background(LinearGradient(
                                            gradient: Gradient(colors: [lightBlue, darkPurple]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                    )
                                    .foregroundColor(.white)
                                    .clipShape(Capsule())
                                }
                            }
                        }
                        .disabled(isCalibrating)
                    }
                    .padding(.bottom, 60)
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                    Text("Back")
                        .foregroundColor(.white)
                }
            })
            .onAppear {
                // Ensure BluetoothManager is subscribed to sensor data notifications
                // This should already be handled in didDiscoverCharacteristicsFor
            }
            .onChange(of: bluetoothManager.sensorData) { newValue in
                // Parse the sensor data (assuming it's a JSON string like {"t":123,"sensors":[100,200,300,400]})
                if isCalibrating, let data = newValue.data(using: .utf8) {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                           let sensors = json["sensors"] as? [Int] {
                            // Add the entire sensors array as a single reading
                            calibrationModel.addReadings(for: .leanRight, readings: sensors)
                        }
                    } catch {
                        print("Error parsing sensor data: \(error)")
                    }
                }
            }
        }
    }
    
    // Start the calibration process
    private func startCalibration() {
        guard !isCalibrating else { return }
        
        // Reset state
        resetCalibration()
        countdownValue = 3
        
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            if let value = countdownValue, value > 1 {
                countdownValue = value - 1
            } else {
                timer.invalidate()
                countdownValue = nil // hide countdown
                beginCalibration()  // start the actual calibration
            }
        }
    }
    
    private func beginCalibration() {
        bluetoothManager.sendCalibrationCommand("CALIBRATE:3")
        print("Sent calibration command 3")

        isCalibrating = true
        elapsedTime = 0

        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            elapsedTime += 1
            if elapsedTime >= 10 {
                stopCalibration()
            }
        }
    }
    
    // Stop the calibration process
    private func stopCalibration() {
        isCalibrating = false
        timer?.invalidate()
        timer = nil
        // Navigation to the next view will happen automatically via NavigationLink when the user taps "Next"
    }
    
    // Reset the calibration state
    private func resetCalibration() {
        isCalibrating = false
        calibrationModel.resetReadings(for: .leanRight)
        elapsedTime = 0
        timer?.invalidate()
        timer = nil
    }
}


#Preview {
    let userModel = UserModel(
        email: "preview@example.com",
        firstName: "Test",
        lastName: "User",
        weight: 160,
        weightUnit: "LB",
        heightFeet: 5,
        heightInches: 10,
        trainingLevel: 3
    )

    return NavigationStack {
        Calibrate3(
            userModel: userModel,
            bluetoothManager: BluetoothManager(),
            calibrationModel: CalibrationModel()
        )
    }
}
