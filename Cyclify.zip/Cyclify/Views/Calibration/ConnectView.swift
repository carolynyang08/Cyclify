//
//  ConnectView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/15/25.
//

import SwiftUI
import SwiftData
import CoreBluetooth


struct ConnectView: View {
    var userModel: UserModel
    @ObservedObject var service: BluetoothManager
    @ObservedObject var calibrationModel: CalibrationModel
    @Environment(\.presentationMode) var presentationMode
    
    let lightBlue = Color(red: 0.0, green: 0.67, blue: 1.0)
    let darkPurple = Color(red: 0.5, green: 0.0, blue: 1.0)
    
    var body: some View {
        ZStack{
        Image("cyclify-bike")
            .resizable()
            .scaledToFit()
            .frame(width: 250, height: 250)
            .foregroundStyle(
                LinearGradient(
                    gradient: Gradient(colors: [lightBlue, darkPurple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .position(x: 40, y: 60)
        
        Image("cyclify-bike")
            .resizable()
            .scaledToFit()
            .frame(width: 250, height: 250)
            .foregroundStyle(
                LinearGradient(
                    gradient: Gradient(colors: [lightBlue, darkPurple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .position(x: UIScreen.main.bounds.width - 30, y: UIScreen.main.bounds.height - 150)
        
        VStack {
            Text("Device Pairing")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            Text(service.peripheralStatus.rawValue.capitalized)
                .font(.title)
                .foregroundColor(statusColor)
                .padding()
            
            //Scan button
            Button(action: {
                print("Scan button pressed")
                service.scanForPeripherals()
            }) {
                Text("Scan for Devices")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(service.peripheralStatus == .scanning ? Color.gray : Color.blue) // Gray out when scanning
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(service.peripheralStatus == .scanning || service.peripheralStatus == .connected || service.peripheralStatus == .connecting)
            .padding(.horizontal)
            
            Button(action: {
                print("Stop scanning button pressed")
                service.stopScanning()
            }) {
                Text("Stop Scanning")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(service.peripheralStatus == .scanning ? Color.red : Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(service.peripheralStatus != .scanning)
            .padding(.horizontal)
            
            
            Button(action: {
                print("Disconnect button pressed")
                service.disconnect()
            }) {
                Text("Disconnect")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(service.peripheralStatus == .connected ? Color.red : Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(service.peripheralStatus != .connected)
            .padding(.horizontal)
            
            // List of discovered devices
            if !service.discoveredPeripherals.isEmpty {
                Text("Discovered Devices:")
                    .font(.headline)
                    .padding(.top)
                
                List(service.discoveredPeripherals, id: \.identifier) { peripheral in
                    Button(action: {
                        service.connect(to: peripheral) // Connect to the selected peripheral
                    }) {
                        Text(peripheral.name ?? "Unknown Device")
                            .foregroundColor(.blue)
                            .padding(.vertical, 5)
                    }
                    .disabled(service.peripheralStatus == .connected || service.peripheralStatus == .connecting)
                }
                .frame(height: 200)
            } else if service.peripheralStatus == .scanning {
                Text("Scanning for devices...")
                    .foregroundColor(.gray)
                    .padding(.top)
            }
            if service.peripheralStatus == .connected {
                NavigationLink(destination: CalibrationStart(userModel: userModel, bluetoothManager: service, calibrationModel: calibrationModel)) {
                    Text("Proceed to Calibration")
                        .font(.headline)
                        .frame(width: 200)
                        .padding()
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.blue, Color.purple]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(20)
                }
                .padding(.horizontal)
            }
            
        }
    }
        .padding()
        .navigationTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image(systemName: "chevron.left")
                    .foregroundColor(.white)
                Text("Back")
                    .foregroundColor(.white)
            }
        })
        .onChange(of: service.peripheralStatus) { newStatus in
            if newStatus == .connected {
                print("Peripheral connected, sending weight: \(userModel.weight) and level: \(userModel.trainingLevel)")
                service.sendWeight(Int(userModel.weight))
                service.sendLevel(userModel.trainingLevel)
            }
        }
    }
        
        

        private var statusColor: Color {
            switch service.peripheralStatus {
            case .connected:
                return .green
            case .disconnected, .error:
                return .red
            case .scanning, .connecting:
                return .orange
            }
        
    }
}

#Preview {
    let user = UserModel(
        email: "preview@example.com",
        firstName: "Preview",
        lastName: "User",
        weight: 160,
        weightUnit: "LB",
        heightFeet: 5,
        heightInches: 11
    )

    return ConnectView(
        userModel: user,
        service: BluetoothManager(),
        calibrationModel: CalibrationModel()
    )
}
