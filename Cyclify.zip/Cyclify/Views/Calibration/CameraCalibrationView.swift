//
//  CameraCalibrationView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 4/17/25.
//
import SwiftUI
import Vision
import AVFoundation

// MARK: - Main View
struct CyclingPoseCalibrationView: View {
    @Environment(\.dismiss) var dismiss
    @State private var showCamera = true
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(alignment: .leading, spacing: 0) {
                // Header
                HStack {
                    Button(action: {
                        dismiss()
                    }) {
                        HStack(spacing: 8) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 20, weight: .semibold))
                            Text("Back")
                                .font(.system(size: 20, weight: .regular))
                        }
                        .foregroundColor(.white)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 8)
                
                Text("Posture Calibration")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 20)
                
                Text("Hold this position while we capture your posture")
                    .font(.system(size: 18, weight: .regular))
                    .foregroundColor(.white.opacity(0.8))
                    .padding(.horizontal, 20)
                    .padding(.top, 4)
                    .padding(.bottom, 20)
                
                // Camera with overlay - using aspect ratio from the reference image
                ImprovedPoseOverlayView()
                    .cornerRadius(12)
                    .aspectRatio(0.75, contentMode: .fit)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 16)
                
                Spacer()
                
                // Bottom buttons
                HStack(spacing: 16) {
                    Button(action: {
                        // Redo action
                    }) {
                        HStack {
                            Image(systemName: "arrow.clockwise")
                            Text("Redo")
                        }
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 24)
                        .background(Color.gray.opacity(0.3))
                        .cornerRadius(30)
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        // Close action
                        dismiss()
                    }) {
                        Text("Close")
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                            .frame(minWidth: 200)
                            .padding(.vertical, 12)
                            .background(
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.blue, Color.purple]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(30)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 40)
                .padding(.top, 20)
            }
        }
    }
}

// MARK: - Improved Pose Overlay View
struct ImprovedPoseOverlayView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> ImprovedPoseOverlayViewController {
        return ImprovedPoseOverlayViewController()
    }
    
    func updateUIViewController(_ uiViewController: ImprovedPoseOverlayViewController, context: Context) {
        // No updates needed
    }
}

// MARK: - Improved Pose Overlay View Controller
class ImprovedPoseOverlayViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    // Camera
    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    
    // Overlay
    private var overlayLayer = CAShapeLayer()
    private var bicycleLayer = CAShapeLayer()
    private var bodyLayer = CAShapeLayer()
    private var angleLabelsLayer = CALayer()
    private var angleArcsLayer = CALayer()
    
    // Update the reference joints to match the ideal posture image more accurately
    private let referenceJoints: [(name: String, position: CGPoint)] = [
        ("head", CGPoint(x: 0.45, y: 0.25)),
        ("neck", CGPoint(x: 0.43, y: 0.28)),
        ("shoulder", CGPoint(x: 0.40, y: 0.30)),
        ("elbow", CGPoint(x: 0.50, y: 0.30)),
        ("wrist", CGPoint(x: 0.60, y: 0.28)),
        ("hip", CGPoint(x: 0.35, y: 0.40)),
        ("knee", CGPoint(x: 0.35, y: 0.55)),
        ("ankle", CGPoint(x: 0.40, y: 0.65)),
        ("foot", CGPoint(x: 0.45, y: 0.67))
    ]
    
    // Update the reference angles positions to match the ideal posture image
    private let referenceAngles: [(joint: String, position: CGPoint, text: String, color: UIColor)] = [
        ("neck", CGPoint(x: 0.30, y: 0.25), "65°-75°", UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1.0)),
        ("shoulder", CGPoint(x: 0.50, y: 0.25), "150°-160°", UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1.0)),
        ("hip", CGPoint(x: 0.25, y: 0.40), "60°-110°", UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1.0)),
        ("knee", CGPoint(x: 0.25, y: 0.55), "65°-145°", UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1.0)),
        ("ankle", CGPoint(x: 0.25, y: 0.65), "115°-180°", UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1.0))
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup camera
        setupCamera()
        
        // Setup overlay
        setupOverlay()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Start session when view appears
        if captureSession?.isRunning == false {
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                self?.captureSession.startRunning()
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Stop session when view disappears
        if captureSession?.isRunning == true {
            captureSession.stopRunning()
        }
    }
    
    private func setupCamera() {
        captureSession = AVCaptureSession()
        
        // Check permission
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configureCaptureSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if granted {
                    DispatchQueue.main.async {
                        self?.configureCaptureSession()
                    }
                } else {
                    DispatchQueue.main.async {
                        self?.showAlertMessage(title: "Camera Access Denied", message: "Please enable camera access in Settings.")
                    }
                }
            }
        case .denied, .restricted:
            showAlertMessage(title: "Camera Access Denied", message: "Please enable camera access in Settings.")
        @unknown default:
            showAlertMessage(title: "Camera Error", message: "Unknown camera permission status.")
        }
    }
    
    private func configureCaptureSession() {
        // Begin configuration
        captureSession.beginConfiguration()
        
        // Setup input - use back camera
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            showAlertMessage(title: "Camera Error", message: "Failed to access camera device.")
            captureSession.commitConfiguration()
            return
        }
        
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            showAlertMessage(title: "Camera Error", message: "Failed to add camera input.")
            captureSession.commitConfiguration()
            return
        }
        
        // Setup output
        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        
        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            showAlertMessage(title: "Camera Error", message: "Failed to add camera output.")
            captureSession.commitConfiguration()
            return
        }
        
        // Commit configuration
        captureSession.commitConfiguration()
        
        // Setup preview layer - IMPORTANT: This must be done on the main thread
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Create preview layer
            self.previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
            self.previewLayer.videoGravity = .resizeAspectFill
            self.previewLayer.connection?.videoOrientation = .portrait
            
            // Add preview layer to view
            self.previewLayer.frame = self.view.bounds
            self.view.layer.insertSublayer(self.previewLayer, at: 0)
            
            // Add bicycle layer
            self.view.layer.addSublayer(self.bicycleLayer)
            
            // Add body layer
            self.view.layer.addSublayer(self.bodyLayer)
            
            // Add angle arcs layer
            self.view.layer.addSublayer(self.angleArcsLayer)
            
            // Add overlay layer
            self.view.layer.addSublayer(self.overlayLayer)
            
            // Add angle labels layer
            self.view.layer.addSublayer(self.angleLabelsLayer)
            
            // Draw the bicycle, stick figure and angle labels
            self.drawBicycle()
            self.drawBodySilhouette()
            self.drawStickFigure()
            self.drawAngleArcs()
            self.drawAngleLabels()
            
            // Start session
            DispatchQueue.global(qos: .userInitiated).async {
                self.captureSession.startRunning()
            }
        }
    }
    
    private func setupOverlay() {
        // Setup overlay layers
        overlayLayer.frame = view.bounds
        overlayLayer.strokeColor = UIColor.yellow.cgColor
        overlayLayer.lineWidth = 3.0
        overlayLayer.fillColor = nil
        
        bicycleLayer.strokeColor = UIColor.lightGray.cgColor
        bicycleLayer.lineWidth = 2.0
        bicycleLayer.fillColor = nil
        
        bodyLayer.frame = view.bounds
        bodyLayer.strokeColor = UIColor.yellow.withAlphaComponent(0.0).cgColor
        bodyLayer.fillColor = UIColor.yellow.withAlphaComponent(0.3).cgColor
        
        angleArcsLayer.frame = view.bounds
        angleLabelsLayer.frame = view.bounds
    }
    
    // Update the drawBicycle method to match the reference image more accurately
    private func drawBicycle() {
        let width = view.bounds.width
        let height = view.bounds.height
        
        // Create bicycle path
        let path = UIBezierPath()
        
        // Frame - adjusted to match the reference image
        let seatTubeTop = CGPoint(x: 0.35 * width, y: 0.40 * height)
        let bottomBracket = CGPoint(x: 0.35 * width, y: 0.65 * height)
        let frontWheel = CGPoint(x: 0.65 * width, y: 0.65 * height)
        let headTubeTop = CGPoint(x: 0.60 * width, y: 0.28 * height)
        
        // Seat tube
        path.move(to: bottomBracket)
        path.addLine(to: seatTubeTop)
        
        // Top tube
        path.move(to: seatTubeTop)
        path.addLine(to: headTubeTop)
        
        // Down tube
        path.move(to: headTubeTop)
        path.addLine(to: bottomBracket)
        
        // Chain stay
        path.move(to: bottomBracket)
        path.addLine(to: frontWheel)
        
        // Handlebars
        path.move(to: headTubeTop)
        path.addLine(to: CGPoint(x: headTubeTop.x, y: headTubeTop.y - 0.03 * height))
        path.move(to: CGPoint(x: headTubeTop.x - 0.05 * width, y: headTubeTop.y - 0.03 * height))
        path.addLine(to: CGPoint(x: headTubeTop.x + 0.05 * width, y: headTubeTop.y - 0.03 * height))
        
        // Front fork
        path.move(to: headTubeTop)
        path.addLine(to: frontWheel)
        
        // Front wheel
        let frontWheelRadius = 0.15 * width
        path.addArc(withCenter: frontWheel, radius: frontWheelRadius, startAngle: 0, endAngle: CGFloat(2.0 * Double.pi), clockwise: true)
        
        // Rear wheel
        let rearWheelCenter = bottomBracket
        let rearWheelRadius = 0.15 * width
        path.addArc(withCenter: rearWheelCenter, radius: rearWheelRadius, startAngle: 0, endAngle: CGFloat(2.0 * Double.pi), clockwise: true)
        
        // Spokes (more detailed)
        for wheel in [frontWheel, rearWheelCenter] {
            for angle in stride(from: 0, to: CGFloat(2.0 * Double.pi), by: CGFloat(Double.pi / 12)) {
                let radius = wheel == frontWheel ? frontWheelRadius : rearWheelRadius
                let x = wheel.x + radius * cos(angle)
                let y = wheel.y + radius * sin(angle)
                path.move(to: wheel)
                path.addLine(to: CGPoint(x: x, y: y))
            }
        }
        
        // Set path to bicycle layer with light gray color
        bicycleLayer.path = path.cgPath
        bicycleLayer.strokeColor = UIColor.lightGray.cgColor
        bicycleLayer.lineWidth = 2.0
        bicycleLayer.fillColor = nil
    }
    
    private func drawBodySilhouette() {
        let width = view.bounds.width
        let height = view.bounds.height
        
        // Create a path for the body silhouette
        let path = UIBezierPath()
        
        // Map normalized positions to actual coordinates
        let points = referenceJoints.map { (name, pos) in
            (name, CGPoint(x: pos.x * width, y: pos.y * height))
        }
        
        // Find points by name
        func findPoint(named name: String) -> CGPoint? {
            return points.first(where: { $0.0 == name })?.1
        }
        
        // Draw body silhouette
        if let head = findPoint(named: "head"),
           let neck = findPoint(named: "neck"),
           let shoulder = findPoint(named: "shoulder"),
           let elbow = findPoint(named: "elbow"),
           let wrist = findPoint(named: "wrist"),
           let hip = findPoint(named: "hip"),
           let knee = findPoint(named: "knee"),
           let ankle = findPoint(named: "ankle"),
           let foot = findPoint(named: "foot") {
        
            // Create a filled path for the body
            let bodyFillPath = UIBezierPath()
            
            // Head
            let headPath = UIBezierPath(arcCenter: head, radius: 15, startAngle: 0, endAngle: CGFloat(2.0 * Double.pi), clockwise: true)
            bodyFillPath.append(headPath)
            
            // Torso (simplified)
            let shoulderWidth: CGFloat = width * 0.03
            bodyFillPath.move(to: CGPoint(x: neck.x, y: neck.y))
            bodyFillPath.addLine(to: CGPoint(x: shoulder.x - shoulderWidth, y: shoulder.y))
            bodyFillPath.addLine(to: CGPoint(x: hip.x - shoulderWidth, y: hip.y))
            bodyFillPath.addLine(to: CGPoint(x: hip.x + shoulderWidth, y: hip.y))
            bodyFillPath.addLine(to: CGPoint(x: shoulder.x + shoulderWidth, y: shoulder.y))
            bodyFillPath.close()
            
            // Arm
            let armWidth: CGFloat = width * 0.02
            let armPath = UIBezierPath()
            armPath.move(to: CGPoint(x: shoulder.x, y: shoulder.y))
            armPath.addLine(to: CGPoint(x: elbow.x, y: elbow.y))
            armPath.addLine(to: CGPoint(x: wrist.x, y: wrist.y))
            armPath.addLine(to: CGPoint(x: wrist.x, y: wrist.y + armWidth))
            armPath.addLine(to: CGPoint(x: elbow.x, y: elbow.y + armWidth))
            armPath.addLine(to: CGPoint(x: shoulder.x, y: shoulder.y + armWidth))
            armPath.close()
            bodyFillPath.append(armPath)
            
            // Leg
            let legWidth: CGFloat = width * 0.03
            
            // Thigh
            let thighPath = UIBezierPath()
            thighPath.move(to: CGPoint(x: hip.x - legWidth/2, y: hip.y))
            thighPath.addLine(to: CGPoint(x: knee.x - legWidth/2, y: knee.y))
            thighPath.addLine(to: CGPoint(x: knee.x + legWidth/2, y: knee.y))
            thighPath.addLine(to: CGPoint(x: hip.x + legWidth/2, y: hip.y))
            thighPath.close()
            bodyFillPath.append(thighPath)
            
            // Lower leg
            let lowerLegPath = UIBezierPath()
            lowerLegPath.move(to: CGPoint(x: knee.x - legWidth/2, y: knee.y))
            lowerLegPath.addLine(to: CGPoint(x: ankle.x - legWidth/2, y: ankle.y))
            lowerLegPath.addLine(to: CGPoint(x: ankle.x + legWidth/2, y: ankle.y))
            lowerLegPath.addLine(to: CGPoint(x: knee.x + legWidth/2, y: knee.y))
            lowerLegPath.close()
            bodyFillPath.append(lowerLegPath)
            
            // Set the filled path to the body layer with yellow color
            bodyLayer.path = bodyFillPath.cgPath
            bodyLayer.fillColor = UIColor.yellow.withAlphaComponent(0.5).cgColor
            bodyLayer.strokeColor = UIColor.yellow.cgColor
            bodyLayer.lineWidth = 1.0
        }
    }
    
    private func drawStickFigure() {
        let width = view.bounds.width
        let height = view.bounds.height
        
        // Map normalized positions to actual coordinates
        let points = referenceJoints.map { (name, pos) in
            (name, CGPoint(x: pos.x * width, y: pos.y * height))
        }
        
        // Create path for stick figure
        let path = UIBezierPath()
        
        // Draw joints
        for (_, point) in points {
            path.move(to: point)
            path.addArc(withCenter: point, radius: 5, startAngle: 0, endAngle: CGFloat(2.0 * Double.pi), clockwise: true)
        }
        
        // Connect joints to form the cyclist figure
        // Find points by name
        func findPoint(named name: String) -> CGPoint? {
            return points.first(where: { $0.0 == name })?.1
        }
        
        // Head to neck
        if let head = findPoint(named: "head"), let neck = findPoint(named: "neck") {
            path.move(to: head)
            path.addLine(to: neck)
        }
        
        // Neck to shoulder
        if let neck = findPoint(named: "neck"), let shoulder = findPoint(named: "shoulder") {
            path.move(to: neck)
            path.addLine(to: shoulder)
        }
        
        // Shoulder to elbow
        if let shoulder = findPoint(named: "shoulder"), let elbow = findPoint(named: "elbow") {
            path.move(to: shoulder)
            path.addLine(to: elbow)
        }
        
        // Elbow to wrist
        if let elbow = findPoint(named: "elbow"), let wrist = findPoint(named: "wrist") {
            path.move(to: elbow)
            path.addLine(to: wrist)
        }
        
        // Shoulder to hip
        if let shoulder = findPoint(named: "shoulder"), let hip = findPoint(named: "hip") {
            path.move(to: shoulder)
            path.addLine(to: hip)
        }
        
        // Hip to knee
        if let hip = findPoint(named: "hip"), let knee = findPoint(named: "knee") {
            path.move(to: hip)
            path.addLine(to: knee)
        }
        
        // Knee to ankle
        if let knee = findPoint(named: "knee"), let ankle = findPoint(named: "ankle") {
            path.move(to: knee)
            path.addLine(to: ankle)
        }
        
        // Ankle to foot
        if let ankle = findPoint(named: "ankle"), let foot = findPoint(named: "foot") {
            path.move(to: ankle)
            path.addLine(to: foot)
        }
        
        // Set path to overlay layer
        overlayLayer.path = path.cgPath
    }
    
    private func drawAngleArcs() {
        // Clear previous arcs
        angleArcsLayer.sublayers?.forEach { $0.removeFromSuperlayer() }
        
        let width = view.bounds.width
        let height = view.bounds.height
        
        // Map normalized positions to actual coordinates
        let points = referenceJoints.map { (name, pos) in
            (name, CGPoint(x: pos.x * width, y: pos.y * height))
        }
        
        // Find points by name
        func findPoint(named name: String) -> CGPoint? {
            return points.first(where: { $0.0 == name })?.1
        }
        
        // Draw angle arcs
        // Neck angle (head - neck - shoulder)
        if let head = findPoint(named: "head"),
           let neck = findPoint(named: "neck"),
           let shoulder = findPoint(named: "shoulder") {
            createAngleArc(center: neck, from: head, to: shoulder, color: UIColor.red)
        }
        
        // Shoulder angle (neck - shoulder - elbow)
        if let neck = findPoint(named: "neck"),
           let shoulder = findPoint(named: "shoulder"),
           let elbow = findPoint(named: "elbow") {
            createAngleArc(center: shoulder, from: neck, to: elbow, color: UIColor.red)
        }
        
        // Hip angle (shoulder - hip - knee)
        if let shoulder = findPoint(named: "shoulder"),
           let hip = findPoint(named: "hip"),
           let knee = findPoint(named: "knee") {
            createAngleArc(center: hip, from: shoulder, to: knee, color: UIColor.red)
        }
        
        // Knee angle (hip - knee - ankle)
        if let hip = findPoint(named: "hip"),
           let knee = findPoint(named: "knee"),
           let ankle = findPoint(named: "ankle") {
            createAngleArc(center: knee, from: hip, to: ankle, color: UIColor.red)
        }
        
        // Ankle angle (knee - ankle - foot)
        if let knee = findPoint(named: "knee"),
           let ankle = findPoint(named: "ankle"),
           let foot = findPoint(named: "foot") {
            createAngleArc(center: ankle, from: knee, to: foot, color: UIColor.red)
        }
    }
    
    private func createAngleArc(center: CGPoint, from startPoint: CGPoint, to endPoint: CGPoint, color: UIColor) {
        // Calculate vectors
        let v1 = CGPoint(x: startPoint.x - center.x, y: startPoint.y - center.y)
        let v2 = CGPoint(x: endPoint.x - center.x, y: endPoint.y - center.y)
        
        // Calculate angles
        let startAngle = atan2(v1.y, v1.x)
        let endAngle = atan2(v2.y, v2.x)
        
        // Create arc path
        let arcPath = UIBezierPath()
        let radius: CGFloat = 25.0
        
        // Determine if we need to go clockwise or counterclockwise
        let clockwise = (startAngle - endAngle).truncatingRemainder(dividingBy: CGFloat(2 * Double.pi)) > 0
        
        arcPath.addArc(withCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: clockwise)
        
        // Create arc layer
        let arcLayer = CAShapeLayer()
        arcLayer.path = arcPath.cgPath
        arcLayer.strokeColor = UIColor.red.cgColor
        arcLayer.lineWidth = 3.0
        arcLayer.fillColor = nil
        
        // Add arc layer to angle arcs layer
        angleArcsLayer.addSublayer(arcLayer)
    }
    
    private func drawAngleLabels() {
        // Remove existing sublayers
        angleLabelsLayer.sublayers?.forEach { $0.removeFromSuperlayer() }
        
        let width = view.bounds.width
        let height = view.bounds.height
        
        // Draw angle labels
        for (joint, position, text, color) in referenceAngles {
            // Create label with background
            let labelLayer = createTextLayer(
                text: text,
                position: CGPoint(x: position.x * width, y: position.y * height),
                color: color
            )
            angleLabelsLayer.addSublayer(labelLayer)
        }
    }
    
    private func createTextLayer(text: String, position: CGPoint, color: UIColor) -> CALayer {
        // Create background layer
        let backgroundLayer = CALayer()
        backgroundLayer.backgroundColor = UIColor.darkGray.withAlphaComponent(0.7).cgColor
        backgroundLayer.cornerRadius = 8
        
        // Create text layer
        let textLayer = CATextLayer()
        textLayer.string = text
        textLayer.fontSize = 14
        textLayer.alignmentMode = .center
        textLayer.foregroundColor = color.cgColor
        textLayer.contentsScale = UIScreen.main.scale
        
        // Calculate size
        let attributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14)]
        let textSize = (text as NSString).size(withAttributes: attributes)
        
        // Set frames
        let padding: CGFloat = 6
        let width = textSize.width + padding * 2
        let height = textSize.height + padding * 2
        
        backgroundLayer.frame = CGRect(
            x: position.x - width/2,
            y: position.y - height/2,
            width: width,
            height: height
        )
        
        textLayer.frame = CGRect(
            x: padding,
            y: (height - textSize.height) / 2,
            width: textSize.width,
            height: textSize.height
        )
        
        // Add text layer to background
        backgroundLayer.addSublayer(textLayer)
        
        return backgroundLayer
    }
    
    // Process video frames
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Just display the camera feed, no processing needed
    }
    
    private func showAlertMessage(title: String, message: String) {
        DispatchQueue.main.async { [weak self] in
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self?.present(alert, animated: true)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        // Update frames when view layout changes
        previewLayer?.frame = view.bounds
        overlayLayer.frame = view.bounds
        bicycleLayer.frame = view.bounds
        bodyLayer.frame = view.bounds
        angleArcsLayer.frame = view.bounds
        angleLabelsLayer.frame = view.bounds
        
        // Redraw everything
        drawBicycle()
        drawBodySilhouette()
        drawStickFigure()
        drawAngleArcs()
        drawAngleLabels()
    }
}

// MARK: - Preview Provider
struct CyclingPoseCalibrationView_Previews: PreviewProvider {
    static var previews: some View {
        CyclingPoseCalibrationView()
    }
}
