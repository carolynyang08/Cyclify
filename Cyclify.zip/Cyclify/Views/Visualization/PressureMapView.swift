//
//  PressureMapView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 4/14/25.
//

import SwiftUI
import UIKit

// MARK: - Data Models

struct PressureSensorReading {
    let timestamp: Double
    let values: [Int]
    
    // Parse from the format you provided
    static func parseFromString(_ string: String) -> [PressureSensorReading] {
        let lines = string.components(separatedBy: .newlines)
        
        return lines.compactMap { line in
            let components = line.components(separatedBy: ": ")
            guard components.count == 2,
                  let timestamp = Double(components[0]),
                  let valuesString = components[1].dropFirst().dropLast().components(separatedBy: ", ")
                    .map({ Int($0) }) as? [Int] else {
                return nil
            }
            
            return PressureSensorReading(timestamp: timestamp, values: valuesString)
        }.sorted(by: { $0.timestamp < $1.timestamp })
    }
}

// Define sensor positions on the bicycle
struct SensorPosition {
    let x: CGFloat
    let y: CGFloat
    let name: String
}

// MARK: - Pressure Map View

struct BicyclePressureMapView: UIViewRepresentable {
    var pressureValues: [Int]
    var maxValue: Int
    
    // Define sensor positions - adjust these to match your bicycle image
    let sensorPositions: [SensorPosition] = [
        SensorPosition(x: 200, y: 190, name: "Left Seat"),      // Sensor 0
        SensorPosition(x: 240, y: 190, name: "Right Seat"),     // Sensor 1
        SensorPosition(x: 220, y: 170, name: "Front Seat"),     // Sensor 2
        SensorPosition(x: 220, y: 210, name: "Back Seat"),      // Sensor 3
        SensorPosition(x: 350, y: 120, name: "Left Handle"),    // Sensor 4
        SensorPosition(x: 350, y: 280, name: "Right Handle")    // Sensor 5
    ]
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        // Clear existing subviews
        uiView.subviews.forEach { $0.removeFromSuperview() }
        
        // Add bicycle image
        let bicycleImageView = UIImageView(image: UIImage(named: "bicycle_overhead"))
        bicycleImageView.contentMode = .scaleAspectFit
        bicycleImageView.frame = uiView.bounds
        uiView.addSubview(bicycleImageView)
        
        // Create heat map overlay
        let heatMapView = UIView()
        heatMapView.frame = uiView.bounds
        heatMapView.backgroundColor = .clear
        uiView.addSubview(heatMapView)
        
        // Draw heat map
        let renderer = UIGraphicsImageRenderer(bounds: uiView.bounds)
        let heatMapImage = renderer.image { ctx in
            for (index, value) in pressureValues.enumerated() {
                if value == 0 { continue } // Skip if no pressure
                
                let normalizedValue = CGFloat(value) / CGFloat(maxValue) // Normalize to 0-1
                let position = sensorPositions[index]
                
                // Scale position to match the image scale
                let scale = min(uiView.bounds.width / 600, uiView.bounds.height / 400)
                let scaledX = (uiView.bounds.width - 600 * scale) / 2 + position.x * scale
                let scaledY = (uiView.bounds.height - 400 * scale) / 2 + position.y * scale
                
                // Draw heat spot
                let radius = max(20, normalizedValue * 50) // Size based on pressure
                let gradient = CGGradient(
                    colorsSpace: CGColorSpaceCreateDeviceRGB(),
                    colors: [
                        UIColor(red: 1, green: 0, blue: 0, alpha: min(0.8, normalizedValue)).cgColor,
                        UIColor(red: 1, green: 0.5, blue: 0, alpha: min(0.6, normalizedValue * 0.8)).cgColor,
                        UIColor(red: 1, green: 1, blue: 0, alpha: min(0.3, normalizedValue * 0.5)).cgColor,
                        UIColor.clear.cgColor
                    ] as CFArray,
                    locations: [0.0, 0.5, 0.8, 1.0]
                )!
                
                ctx.cgContext.drawRadialGradient(
                    gradient,
                    startCenter: CGPoint(x: scaledX, y: scaledY),
                    startRadius: 0.0,
                    endCenter: CGPoint(x: scaledX, y: scaledY),
                    endRadius: radius,
                    options: .drawsBeforeStartLocation
                )
            }
        }
        
        let heatOverlayImageView = UIImageView(image: heatMapImage)
        heatOverlayImageView.frame = uiView.bounds
        heatMapView.addSubview(heatOverlayImageView)
    }
}

// MARK: - Main View

struct BicyclePressureVisualizationView: View {
    @State private var pressureReadings: [PressureSensorReading] = []
    @State private var currentIndex: Int = 0
    @State private var isPlaying: Bool = false
    @State private var timer: Timer?
    
    let maxPressureValue: Int = 4000 // Based on your data
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Bicycle Posture Correction")
                .font(.title)
                .padding(.top)
            
            // Pressure map visualization
            ZStack(alignment: .topTrailing) {
                if !pressureReadings.isEmpty {
                    BicyclePressureMapView(
                        pressureValues: pressureReadings[currentIndex].values,
                        maxValue: maxPressureValue
                    )
                    .frame(height: 300)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 2)
                } else {
                    Text("No data available")
                        .frame(height: 300)
                        .frame(maxWidth: .infinity)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(12)
                }
                
                Button(action: {
                    isPlaying.toggle()
                    if isPlaying {
                        startPlayback()
                    } else {
                        stopPlayback()
                    }
                }) {
                    Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                        .padding(8)
                        .background(Color.white.opacity(0.8))
                        .clipShape(Circle())
                        .shadow(radius: 1)
                }
                .padding(8)
            }
            
            // Timeline slider
            if !pressureReadings.isEmpty {
                VStack(spacing: 4) {
                    Slider(
                        value: Binding(
                            get: { Double(currentIndex) },
                            set: {
                                currentIndex = Int($0)
                                if isPlaying {
                                    isPlaying = false
                                    stopPlayback()
                                }
                            }
                        ),
                        in: 0...Double(max(0, pressureReadings.count - 1)),
                        step: 1
                    )
                    
                    HStack {
                        Text(formatTime(pressureReadings.first?.timestamp ?? 0))
                            .font(.caption)
                        
                        Spacer()
                        
                        Text(formatTime(pressureReadings[currentIndex].timestamp))
                            .font(.caption)
                            .bold()
                        
                        Spacer()
                        
                        Text(formatTime(pressureReadings.last?.timestamp ?? 0))
                            .font(.caption)
                    }
                }
                .padding(.horizontal)
            }
            
            // Pressure statistics
            if !pressureReadings.isEmpty {
                PressureStatsView(pressureValues: pressureReadings[currentIndex].values)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(radius: 2)
            }
        }
        .padding()
        .background(Color(.systemGroupedBackground))
        .onAppear {
            loadPressureData()
        }
        .onDisappear {
            stopPlayback()
        }
    }
    
    private func loadPressureData() {
        // In a real app, you would load this from a file or sensor data
        let rawData = """
39.296: [2096, 2010, 3751, 709, 2833, 3520]
21.666: [3327, 2749, 0, 1971, 3138, 3679]
46.344: [3695, 2836, 3088, 1867, 3330, 1891]
52.9: [3856, 2942, 2447, 2364, 3355, 2257]
41.816: [2160, 1883, 3833, 745, 2690, 3531]
6.044: [3152, 2895, 2759, 3099, 3022, 3071]
40.812: [2149, 1811, 3696, 852, 2728, 3563]
34.758: [2166, 1957, 3761, 660, 1866, 3471]
44.838: [2112, 1879, 3771, 1265, 2587, 3579]
8.062: [3045, 2870, 2854, 3167, 3014, 2999]
"""
        pressureReadings = PressureSensorReading.parseFromString(rawData)
    }
    
    private func startPlayback() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            if currentIndex < pressureReadings.count - 1 {
                currentIndex += 1
            } else {
                currentIndex = 0
                isPlaying = false
                stopPlayback()
            }
        }
    }
    
    private func stopPlayback() {
        timer?.invalidate()
        timer = nil
    }
    
    private func formatTime(_ seconds: Double) -> String {
        let minutes = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", minutes, secs)
    }
}

// MARK: - Pressure Statistics View

struct PressureStatsView: View {
    var pressureValues: [Int]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Posture Analysis")
                .font(.headline)
            
            // Posture status
            HStack {
                statusIcon
                    .foregroundColor(statusColor)
                
                VStack(alignment: .leading) {
                    Text("Posture Status: \(postureStatus)")
                        .font(.subheadline)
                        .bold()
                    
                    Text(postureMessage)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding()
            .background(statusColor.opacity(0.1))
            .cornerRadius(8)
            
            // Left/Right balance
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Left/Right Balance")
                        .font(.subheadline)
                    
                    Spacer()
                    
                    Text("\(leftPercentage, specifier: "%.1f")% / \(rightPercentage, specifier: "%.1f")%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                GeometryReader { geometry in
                    HStack(spacing: 0) {
                        Rectangle()
                            .fill(Color.blue)
                            .frame(width: geometry.size.width * CGFloat(leftPercentage) / 100)
                        
                        Rectangle()
                            .fill(Color.green)
                            .frame(width: geometry.size.width * CGFloat(rightPercentage) / 100)
                    }
                    .frame(height: 8)
                    .cornerRadius(4)
                }
                .frame(height: 8)
            }
            
            // Sensor readings
            VStack(alignment: .leading, spacing: 12) {
                Text("Sensor Readings")
                    .font(.subheadline)
                
                ForEach(0..<pressureValues.count, id: \.self) { index in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(sensorName(for: index))
                                .font(.caption)
                            
                            Spacer()
                            
                            Text("\(pressureValues[index])")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        GeometryReader { geometry in
                            Rectangle()
                                .fill(sensorColor(for: index))
                                .frame(width: geometry.size.width * CGFloat(pressureValues[index]) / 4000)
                                .frame(height: 6)
                                .cornerRadius(3)
                        }
                        .frame(height: 6)
                    }
                }
            }
            
            // Recommendations
            if !recommendations.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Recommendations")
                        .font(.subheadline)
                    
                    ForEach(recommendations, id: \.self) { recommendation in
                        HStack(alignment: .top) {
                            Image(systemName: "arrow.right")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(recommendation)
                                .font(.caption)
                        }
                    }
                }
                .padding(.top, 4)
            }
        }
    }
    
    // Helper functions and computed properties
    
    private func sensorName(for index: Int) -> String {
        let names = ["Left Seat", "Right Seat", "Front Seat", "Back Seat", "Left Handle", "Right Handle"]
        return index < names.count ? names[index] : "Sensor \(index)"
    }
    
    private func sensorColor(for index: Int) -> Color {
        let colors: [Color] = [.blue, .green, .orange, .purple, .pink, .yellow]
        return index < colors.count ? colors[index] : .gray
    }
    
    private var leftSensors: [Int] { [0, 2, 4] } // Left side sensors
    private var rightSensors: [Int] { [1, 3, 5] } // Right side sensors
    
    private var leftPressure: Int {
        leftSensors.reduce(0) { sum, index in
            index < pressureValues.count ? sum + pressureValues[index] : sum
        }
    }
    
    private var rightPressure: Int {
        rightSensors.reduce(0) { sum, index in
            index < pressureValues.count ? sum + pressureValues[index] : sum
        }
    }
    
    private var totalPressure: Int { leftPressure + rightPressure }
    
    private var leftPercentage: Double {
        totalPressure > 0 ? Double(leftPressure) / Double(totalPressure) * 100 : 50
    }
    
    private var rightPercentage: Double {
        totalPressure > 0 ? Double(rightPressure) / Double(totalPressure) * 100 : 50
    }
    
    private var imbalance: Double { abs(leftPercentage - rightPercentage) }
    
    private var postureStatus: String {
        if imbalance <= 10 {
            return "Good"
        } else if imbalance <= 20 {
            return "Fair"
        } else {
            return "Poor"
        }
    }
    
    private var statusIcon: Image {
        if imbalance <= 10 {
            return Image(systemName: "checkmark.circle.fill")
        } else if imbalance <= 20 {
            return Image(systemName: "exclamationmark.triangle.fill")
        } else {
            return Image(systemName: "xmark.circle.fill")
        }
    }
    
    private var statusColor: Color {
        if imbalance <= 10 {
            return .green
        } else if imbalance <= 20 {
            return .orange
        } else {
            return .red
        }
    }
    
    private var postureMessage: String {
        if imbalance <= 10 {
            return "Your weight is well distributed."
        } else if imbalance <= 20 {
            return "Your weight distribution could be improved."
        } else {
            return "Your weight is unevenly distributed."
        }
    }
    
    private var recommendations: [String] {
        var tips: [String] = []
        
        if leftPercentage > rightPercentage + 10 {
            tips.append("Shift your weight more to the right side")
        }
        
        if rightPercentage > leftPercentage + 10 {
            tips.append("Shift your weight more to the left side")
        }
        
        if pressureValues.count >= 4 {
            if pressureValues[2] > pressureValues[3] * Int(1.5) {
                tips.append("You're leaning too far forward on the seat")
            }
            
            if pressureValues[3] > pressureValues[2] * Int(1.5) {
                tips.append("You're leaning too far back on the seat")
            }
        }
        
        if pressureValues.count >= 6 {
            if pressureValues[4] > pressureValues[5] * Int(1.5) {
                tips.append("Distribute weight more evenly on handlebars")
            }
            
            if pressureValues[5] > pressureValues[4] * Int(1.5) {
                tips.append("Distribute weight more evenly on handlebars")
            }
        }
        
        if tips.isEmpty && imbalance <= 10 {
            tips.append("Good posture! Keep maintaining this balance.")
        }
        
        return tips
    }
}

// MARK: - Preview

struct BicyclePressureVisualizationView_Previews: PreviewProvider {
    static var previews: some View {
        BicyclePressureVisualizationView()
    }
}
