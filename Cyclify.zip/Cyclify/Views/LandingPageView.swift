//
//  ContentView.swift
//  Cyclify
//
//  Created by Carolyn Yang on 2/24/25.
//

import SwiftUI
import SwiftData

struct LandingPageView: View {
    var body: some View {
        Text("Hello, world!")
    }
}

#Preview {
    LandingPageView()
}
