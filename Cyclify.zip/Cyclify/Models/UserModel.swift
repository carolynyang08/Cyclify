//
//  UserModel.swift
//  Cyclify
//
//  Created by Carolyn Yang on 2/24/25.
//
// Handles User Info
// Store non-sensitive data in @AppStorage
// Store sensitive data in the Keychain
import Foundation
import SwiftData
import Security

@Model
class UserModel {
    // User attributes
    @Attribute(.unique) var email: String
    var firstName: String
    var lastName: String
    var weight: Double
    var weightUnit: String
    var heightFeet: Int
    var heightInches: Int
    var trainingLevel: Int
    var isLoggedIn: Bool = false
    @Relationship(deleteRule: .cascade, inverse: \Ride.user)
    var rides: [Ride] = []
    
    // Initializer
    init(email: String, firstName: String, lastName: String, weight: Double, weightUnit: String, heightFeet: Int, heightInches: Int, trainingLevel: Int = 1) {
        self.email = email
        self.firstName = firstName
        self.lastName = lastName
        self.weight = weight
        self.weightUnit = weightUnit
        self.heightFeet = heightFeet
        self.heightInches = heightInches
        self.trainingLevel = trainingLevel
    }
    
    // MARK: - Keychain Management
    
    /// Saves the password to the Keychain.
    /// - Parameter password: The user's password.
    func savePassword(_ password: String) {
        let passwordData = Data(password.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: email,
            kSecValueData as String: passwordData
        ]
        
        // Delete any existing item before adding a new one
        SecItemDelete(query as CFDictionary)
        
        let status = SecItemAdd(query as CFDictionary, nil)
        if status != errSecSuccess {
            print("Error saving password: \(status)")
        }
    }
    
    /// Retrieves the password from the Keychain.
    /// - Returns: The user's password if it exists, otherwise nil.
    func retrievePassword() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: email,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        
        var retrievedData: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &retrievedData)
        if status == errSecSuccess, let data = retrievedData as? Data, let password = String(data: data, encoding: .utf8) {
            return password
        } else {
            print("Error retrieving password: \(status)")
            return nil
        }
    }
    
    /// Deletes the password from the Keychain.
    func deletePassword() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: email
        ]
        
        let status = SecItemDelete(query as CFDictionary)
        if status != errSecSuccess {
            print("Error deleting password: \(status)")
        }
    }
    
    func checkPassword(_ password: String) -> Bool {
        let key = "password_\(email)"
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)

        if status == errSecSuccess,
           let passwordData = result as? Data,
           let storedPassword = String(data: passwordData, encoding: .utf8) {
            return storedPassword == password
        }

        return false
    }

}

    // MARK: - Authentication

    /// Validates the provided password against the stored password.
    /// - Parameter password: The password to validate.
    /// -





//class UserModel: ObservableObject {
//    @AppStorage("firstName") var firstName: String = ""
//    @AppStorage("lastName") var lastName: String = ""
//    @AppStorage("weight") var weight: Double = 0.0
//    @AppStorage("weightUnit") var weightUnit: String = "LB"
//    @AppStorage("heightFeet") var heightFeet: Int = 0
//    @AppStorage("heightInches") var heightInches: Int = 0
//    @AppStorage("isRegistered") var isRegistered: Bool = false
//    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false
//    @AppStorage("trainingLevel") var trainingLevel: Int = 1
//    
//    private var keychain = Keychain(service: "com.Cyclify")
//    private let emailKey = "email"
//    private let passwordKey = "password"
//    
//    var email: String {
//        get {keychain[emailKey] ?? ""}
//        set {keychain[emailKey] = newValue}
//    }
//    
//    var password: String {
//        get {keychain[passwordKey] ?? ""}
//        set {keychain[passwordKey] = newValue}
//    }
//    
//    var fullName: String {
//        return "\(firstName) \(lastName)".trimmingCharacters(in: .whitespaces)
//    }
//    
//    func save(firstName: String, lastName: String, email: String, password: String, weight: Double = 0.0, weightUnit: String = "LB", heightFeet: Int=0, heightInches: Int = 0){
//        self.firstName = firstName
//        self.lastName = lastName
//        self.email = email
//        self.password = password
//        self.weight = weight
//        self.weightUnit = weightUnit
//        self.heightFeet = heightFeet
//        self.heightInches = heightInches
//        self.isRegistered = true
//        self.isLoggedIn = true
//    }
//    
//    func login(email: String, password: String) -> Bool {
//        if self.email == email && self.password == password {
//            self.isLoggedIn = true
//            return true
//        }
//        return false
//    }
//    
//    func clearSensitiveData() {
//            keychain[emailKey] = nil
//            keychain[passwordKey] = nil
//            isRegistered = false
//            isLoggedIn = false
//    }
//    
//    
//    func reset() {
//            firstName = ""
//            lastName = ""
//            weight = 0.0
//            weightUnit = "LB"
//            heightFeet = 0
//            heightInches = 0
//            isRegistered = false
//            isLoggedIn = false
//        }
//    
//    
//    
//}
//
    
