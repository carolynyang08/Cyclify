//
//  PostDetectionViewModel.swift
//  Cyclify
//
//  Created by Carolyn Yang on 4/17/25.
//

import Foundation
import AVFoundation
import Vision
import Combine
import UIKit

// Body angles structure
struct BodyAngles {
    var neck: CGFloat = 0
    var torso: CGFloat = 0
    var arms: CGFloat = 0
    var hips: CGFloat = 0
    var legs: CGFloat = 0
}

class PoseDetectionViewModel: NSObject, ObservableObject {
    // Camera and capture session
    let session = AVCaptureSession()
    private var videoOutput = AVCaptureVideoDataOutput()
    
    // Camera position
    @Published var cameraPosition: AVCaptureDevice.Position = .front
    
    // Vision request
    private var requests = [VNRequest]()
    
    // Pose data
    @Published var joints: [CGPoint] = []
    @Published var angles: BodyAngles = BodyAngles()
    
    // Angle correctness flags
    @Published var isNeckAngleCorrect: Bool = false
    @Published var isTorsoAngleCorrect: Bool = false
    @Published var isArmsAngleCorrect: Bool = false
    @Published var isHipsAngleCorrect: Bool = false
    @Published var isLegsAngleCorrect: Bool = false
    @Published var isInCorrectPose: Bool = false
    
    // Camera state
    @Published var isCameraInitialized: Bool = false
    
    // Cancellables
    private var cancellables = Set<AnyCancellable>()
    
    override init() {
        super.init()
        setupVision()
    }
    
    func checkCameraPermission() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            self.setupCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted {
                    DispatchQueue.main.async {
                        self.setupCamera()
                    }
                }
            }
        default:
            break
        }
    }
    
    private func setupCamera() {
        // Stop the session if it's running
        if session.isRunning {
            session.stopRunning()
        }
        
        // Remove existing inputs
        for input in session.inputs {
            session.removeInput(input)
        }
        
        session.beginConfiguration()
        
        // Add video input based on selected position
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: cameraPosition),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            print("Failed to get camera device or input")
            return
        }
        
        if session.canAddInput(videoInput) {
            session.addInput(videoInput)
        }
        
        // Add video output if not already added
        if session.outputs.isEmpty {
            videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
            if session.canAddOutput(videoOutput) {
                session.addOutput(videoOutput)
            }
        }
        
        session.commitConfiguration()
        
        // Start the session on a background thread
        DispatchQueue.global(qos: .background).async { [weak self] in
            self?.session.startRunning()
            DispatchQueue.main.async {
                self?.isCameraInitialized = true
            }
        }
    }
    
    func toggleCamera() {
        // Toggle camera position
        cameraPosition = (cameraPosition == .front) ? .back : .front
        
        // Reconfigure camera with new position
        setupCamera()
    }
    
    private func setupVision() {
        let poseRequest = VNDetectHumanBodyPoseRequest { [weak self] request, error in
            guard let self = self,
                  let results = request.results as? [VNHumanBodyPoseObservation],
                  let observation = results.first else {
                return
            }
            
            DispatchQueue.main.async {
                self.processObservation(observation)
            }
        }
        
        self.requests = [poseRequest]
    }
    
    private func processObservation(_ observation: VNHumanBodyPoseObservation) {
        // Extract joint points
        var points: [CGPoint] = []
        let jointNames: [VNHumanBodyPoseObservation.JointName] = [
            .nose, .neck,
            .leftShoulder, .leftElbow, .leftWrist,
            .rightShoulder, .rightElbow, .rightWrist,
            .root,
            .leftHip, .leftKnee, .leftAnkle,
            .rightHip, .rightKnee, .rightAnkle
        ]
        
        for jointName in jointNames {
            if let point = try? observation.recognizedPoint(jointName) {
                // Convert normalized coordinates to view coordinates
                let viewPoint = CGPoint(
                    x: point.location.x * UIScreen.main.bounds.width,
                    y: (1 - point.location.y) * UIScreen.main.bounds.height
                )
                points.append(viewPoint)
            } else {
                // If joint not detected, add a placeholder
                points.append(CGPoint(x: -1, y: -1))
            }
        }
        
        self.joints = points
        
        // Calculate angles
        calculateAngles()
        
        // Check if pose is correct
        checkPoseCorrectness()
    }
    
    private func calculateAngles() {
        // Fix: Check for the correct number of joints (15 instead of 17)
        if joints.count >= 15 {
            // Calculate neck angle (between nose, neck, and root)
            angles.neck = calculateAngle(joints[0], joints[1], joints[8])
            
            // Calculate torso angle (between neck, root, and left hip)
            angles.torso = calculateAngle(joints[1], joints[8], joints[9])
            
            // Calculate arm angle (between neck, left shoulder, and left elbow)
            angles.arms = calculateAngle(joints[1], joints[2], joints[3])
            
            // Calculate hip angle (between root, left hip, and left knee)
            angles.hips = calculateAngle(joints[8], joints[9], joints[10])
            
            // Calculate leg angle (between left hip, left knee, and left ankle)
            angles.legs = calculateAngle(joints[9], joints[10], joints[11])
        }
    }
    
    private func calculateAngle(_ joint1: CGPoint, _ joint2: CGPoint, _ joint3: CGPoint) -> CGFloat {
        let vector1 = CGPoint(x: joint1.x - joint2.x, y: joint1.y - joint2.y)
        let vector2 = CGPoint(x: joint3.x - joint2.x, y: joint3.y - joint2.y)
        
        let dot = vector1.x * vector2.x + vector1.y * vector2.y
        let mag1 = sqrt(vector1.x * vector1.x + vector1.y * vector1.y)
        let mag2 = sqrt(vector2.x * vector2.x + vector2.y * vector2.y)
        
        // Avoid division by zero
        if mag1 * mag2 == 0 {
            return 0
        }
        
        let cosAngle = dot / (mag1 * mag2)
        let angle = acos(min(max(cosAngle, -1.0), 1.0)) * 180 / .pi
        
        return angle
    }
    
    private func checkPoseCorrectness() {
        // Check if each angle is within the correct range
        isNeckAngleCorrect = angles.neck >= 65 && angles.neck <= 75
        isTorsoAngleCorrect = angles.torso >= 60 && angles.torso <= 110
        isArmsAngleCorrect = angles.arms >= 150 && angles.arms <= 160
        isHipsAngleCorrect = angles.hips >= 65 && angles.hips <= 145
        isLegsAngleCorrect = angles.legs >= 115 && angles.legs <= 180
        
        // Overall pose correctness
        isInCorrectPose = isNeckAngleCorrect && isTorsoAngleCorrect &&
                          isArmsAngleCorrect && isHipsAngleCorrect && isLegsAngleCorrect
    }
}

// Extension to handle camera buffer processing
extension PoseDetectionViewModel: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return
        }
        
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        
        do {
            try imageRequestHandler.perform(self.requests)
        } catch {
            print("Failed to perform Vision request: \(error)")
        }
    }
}
