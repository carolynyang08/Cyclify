//
//  RideTip.swift
//  Cyclify
//
//  Created by Carolyn Yang on 2/24/25.
//
//  Stores ride tips


//import Foundation
//import SwiftUI
//
//
//class RideModel: ObservableObject {
//    @Published var rides: [Ride] = []
//    @Published var currentRide: Ride?
//    //    @Published var currentSensorData: [SensorReading] = []
//    
//    func startRide() {
//        currentRide = Ride(id: UUID(), startTime: Date())
//    }
//    
//    func stopRide() {
//        guard var ride = currentRide else { return }
//        ride.endTime = Date()
//        var completedRide = ride
//        completedRide.endTime = Date()
//        rides.append(completedRide)
//        currentRide = nil
//        
//        print("Ride ended:")
//        print("Start Time: \(ride.startTime)")
//        print("End Time: \(ride.endTime!)")
//        print("Duration: \(ride.formattedDuration)")
//        print("______________________________________________________________")
//        print("All Rides:")
//        for ride in rides {
//            print("""
//            • Start: \(ride.formattedStartTime)
//              Duration: \(ride.formattedDuration)
//              Avg HR: \(ride.averageHeartRate ?? 0)
//              Calories: \(ride.caloriesBurned ?? 0)
//            """)
//            
//            printRideData(ride)
//            }
//        }
//        
//        
//        func appendSensorReading(_ reading: SensorReading) {
//            currentRide?.sensorData.append(reading)
////            ride.sensorData.append(reading)
//            print("Appended reading. Total count: \(currentRide?.sensorData.count ?? -1)")
////            currentRide = ride
//        }
//        
//        func printRideData(_ ride: Ride) {
//            print("Ride from \(ride.startTime) to \(ride.endTime ?? Date())")
//            print("Sensor Data Points: \(ride.sensorData.count)")
//            for (index, reading) in ride.sensorData.enumerated() {
//                print("Reading \(index + 1): Timestamp: \(reading.timestamp), Sensors: \(reading.sensors)")
//            }
//        }
//
//        
//        
//        //    func printRideData(_ ride: Ride) {
//        //        print("Ride from \(ride.startTime) to \(ride.endTime ?? Date())")
//        //
//        //        if let data = ride.sensorData {
//        //            print("Sensor Data Points: \(data.count)")
//        //            for (index, reading) in data.enumerated() {
//        //                print("Reading \(index + 1): Timestamp: \(reading.timestamp), Sensors: \(reading.sensors)")
//        //            }
//        //        } else {
//        //            print("No sensor data available for this ride.")
//        //        }
//        //    }
//        //
//        //    func addSensorData(_ reading: SensorReading) {
//        //        currentSensorData.append(reading)
//        //        }
//        func resetRides() {
//            rides = []
//        }
//        
//    }
//
//
