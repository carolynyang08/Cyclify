//
//  BluetoothManager.swift
//  Cyclify
//
//  Created by Carolyn Yang on 3/15/25.
//  Responsible for managing BLE connections
import Foundation
import CoreBluetooth
import SwiftData
import SwiftUI
import AVFoundation


enum ConnectionStatus: String{
    case connected
    case disconnected
    case scanning
    case connecting
    case error
    
}

//IDS & CHARACTERISTICS
let SERVICE_UUID: CBUUID = CBUUID(string: "20252025-0000-4000-8000-202520252025") // Crashes //bluetooth service id
let UUID_WEIGHT: CBUUID = CBUUID(string: "20252025-0001-4000-8000-202520252025")
let UUID_LEVEL: CBUUID = CBUUID(string: "20252025-0002-4000-8000-202520252025")
let UUID_CALIBRATE_CMD: CBUUID = CBUUID(string: "20252025-0003-4000-8000-202520252025")
let UUID_RIDE_CONTROL: CBUUID = CBUUID(string: "20252025-0004-4000-8000-202520252025")
let UUID_SENSOR_DATA: CBUUID = CBUUID(string: "20252025-1001-4000-8000-202520252025") //receiving
let UUID_SENSOR_ALERT: CBUUID = CBUUID(string: "20252025-1002-4000-8000-202520252025") //receiving


class BluetoothManager: NSObject, ObservableObject {
    var modelContext: ModelContext?
    private var centralManager: CBCentralManager! //manages BLE Central role
    var espPeripheral: CBPeripheral?
    @Published var bufferedReadings: [SensorReading] = []
    @Published var bufferedAlerts: [RideAlert] = []

    private var weightCharacteristic: CBCharacteristic?
    private var levelCharacteristic: CBCharacteristic?
    private var calibrateCharacteristic: CBCharacteristic?
    private var rideControlCharacteristic: CBCharacteristic?
    private let speechSynthesizer = AVSpeechSynthesizer()
//    private var queuedAlerts: [String] = []
    private var speechTimer: Timer?
    private var isRideActive: Bool = false
    
    //Buffer to track incoming alerts in real time
    private var alertHistory: [(timestamp: TimeInterval, alert: RideAlert)] = []
    private var lastSpokenType: Int? = nil
    private var lastSpokenTime: Date? = nil


    
    @Published var peripheralStatus: ConnectionStatus = .disconnected
    @Published var discoveredPeripherals: [CBPeripheral] = []
    @Published var sensorData: String = "Waiting for sensor data"
    @Published var alertMessage: String = ""
    
    
//    @Published var rideModel: RideModel?
    
    
    private var pendingWeight: Int?
    private var pendingLevel: Int?
    private var pendingCalibrationCommand: String?
    private var pendingRideControl: String?
    
    var currentRide: Ride?
   
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
//    init(rideModel: RideModel? = nil) {
//        self.rideModel = rideModel
//        super.init()
//        centralManager = CBCentralManager(delegate: self, queue: nil)
//    }
    
//    override init() {
//        super.init() //NSObject
//        centralManager = CBCentralManager(delegate: self, queue: nil)
//    }
    
    func startRide() {
        isRideActive = true
        startSpeechTimer()
    }
    
    func stopRide() {
        isRideActive = false
        speechTimer?.invalidate()
        speechTimer = nil
        speechSynthesizer.stopSpeaking(at: .immediate)
        alertHistory.removeAll()
    }

    private func startSpeechTimer() {
        speechTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
            self?.evaluateRecentAlerts()
        }
    }

    private func evaluateRecentAlerts() {
        guard isRideActive else { return }

        let now = Date()
        let windowStart = now.timeIntervalSince1970 - 6.5

        // Filter alerts in last 5 seconds
        let recentAlerts = alertHistory.filter { $0.timestamp >= windowStart }

        // Count frequencies
        let frequencyMap = Dictionary(grouping: recentAlerts, by: { $0.alert.type })
            .mapValues { $0.count }

        guard let (mostFrequentType, _) = frequencyMap.max(by: { $0.value < $1.value }) else { return }

        // Cooldown logic
        if let lastType = lastSpokenType,
           let lastTime = lastSpokenTime,
           mostFrequentType == lastType,
           now.timeIntervalSince(lastTime) < 7 {
            return
        }

        // Speak it
        if let alertType = AlertType(rawValue: mostFrequentType),
           let intensity = recentAlerts.first(where: { $0.alert.type == mostFrequentType })?.alert.intensity {

            let message = alertType.message(forIntensity: intensity)
            speak(message: message)
            lastSpokenType = mostFrequentType
            lastSpokenTime = now
        }
    }

    
    func speak(message: String) {
        let utterance = AVSpeechUtterance(string: message)
        utterance.voice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.siri_female_en-US_compact") // "Shelley"
        utterance.rate = 0.5
        speechSynthesizer.speak(utterance)
    }
    
    //search for bluetooth devices (User presses "Scan for Devices")
    func scanForPeripherals() {
        if centralManager.state == .poweredOn {
            if peripheralStatus != .scanning {
                peripheralStatus = .scanning
                discoveredPeripherals.removeAll()
                centralManager.scanForPeripherals(withServices: [SERVICE_UUID])
                print("Started scanning for peripherals")
                //centralManager.scanForPeripherals(withServices: [SERVICE_UUID]) //only triggered for this service
            }else {
                print("Already scanning for peripherals")
            }
        } else {
            peripheralStatus = .error
            print("Cannot scan: Bluetooth is not powered on.")
        }
    }
    
    func stopScanning() {
        if peripheralStatus == .scanning {
            centralManager.stopScan()
            peripheralStatus = .disconnected
            print("Stopping scanning for peripherals")
        }
    }
    
    func connect(to peripheral: CBPeripheral){
        if peripheralStatus != .connected && peripheralStatus != .connecting {
            espPeripheral = peripheral
            centralManager.connect(peripheral) // Initiates the connection
            peripheralStatus = .connecting // Sets status to .connecting
            stopScanning()
            print("Attempting to connect to \(peripheral.name ?? "Unknown Device")")
        } else {
            print("Cannot connect: Already connected or connecting.")
        }
    }
    
    func disconnect() {
        if let peripheral = espPeripheral {
            centralManager.cancelPeripheralConnection(peripheral)
            peripheralStatus = .disconnected
            espPeripheral = nil
            weightCharacteristic = nil
            levelCharacteristic = nil
            calibrateCharacteristic = nil
            rideControlCharacteristic = nil
            pendingWeight = nil
            pendingLevel = nil
            pendingCalibrationCommand = nil
            pendingRideControl = nil
            print("Disconnected from \(peripheral.name ?? "Unknown Device")")
        }
    }
    
    func sendWeight(_ weight: Int){
        guard let peripheral = espPeripheral, let characteristic = weightCharacteristic else {
            print("Cannot send weight: No connected peripheral or weight characteristic.")
            pendingWeight = weight
            return
        }
        
        let weightString = String(weight)
        if let data = weightString.data(using: .utf8) {
            peripheral.writeValue(data, for: characteristic, type: .withResponse)
            print("Sent weight: \(weightString)")
        }
    }
    
    func sendLevel(_ level: Int) {
        guard let peripheral = espPeripheral, let characteristic = levelCharacteristic else {
            print("Cannot send level: No connected peripheral or level characteristic.")
            pendingLevel = level
            return
        }
        let levelString = String(level)
        if let data = levelString.data(using: .utf8) {
            peripheral.writeValue(data, for: characteristic, type: .withResponse)
            print("Sent level: \(levelString)")
        }
    }
    
    func sendCalibrationCommand(_ command: String){
        guard let peripheral = espPeripheral, let characteristic = calibrateCharacteristic else {
            print("Cannot send calibration command: No connected peripheral or calibration characteristic")
            pendingCalibrationCommand = command
            return
        }
        
        if let data = command.data(using: .utf8){
            peripheral.writeValue(data, for: characteristic, type: .withResponse)
            print("Sent calibration command: \(command)")
        }
    }
    
    func sendRideControl(_ command: String){
        guard let peripheral = espPeripheral, let characteristic = rideControlCharacteristic else {
            print("Cannot send rideControl command: No connected peripheral or rideControl characteristic")
            pendingRideControl = command
            return
        }
        
        if let data = command.data(using: .utf8){
            peripheral.writeValue(data, for: characteristic, type: .withResponse)
            print("Sent ride control command: \(command)")
        }
    }
    
    func speak(message: String, intensity: Int) {
        let utterance = AVSpeechUtterance(string: message)
        if let shelleyVoice = AVSpeechSynthesisVoice.speechVoices().first(where: { $0.name == "Shelley" && $0.language == "en-US" }) {
            utterance.voice = shelleyVoice
        } else {
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US") // fallback
        }

        
        switch intensity {
            case 1: utterance.rate = 0.3
            case 2: utterance.rate = 0.4
            case 3: utterance.rate = 0.5
            case 4: utterance.rate = 0.6
            case 5: utterance.rate = 0.7
            default: utterance.rate = 0.45
            }

        speechSynthesizer.speak(utterance)
    }

}



extension BluetoothManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager){
        //anytime state changes of the central manager, it will come through here
        switch central.state {
        case .poweredOn:
            print("Bluetooth is powered on.")
            peripheralStatus = .disconnected
        case .poweredOff:
            print("Bluetooth is powered off.")
            peripheralStatus = .error
        case .unauthorized:
            print("Bluetooth access is not authorized.")
            peripheralStatus = .error
        default:
            print("Bluetooth state unknown: \(central.state)")
            peripheralStatus = .error
        
        }
    }
    
    //When central manager discovers a peripheral
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        if !discoveredPeripherals.contains(where: { $0.identifier == peripheral.identifier }) {
            discoveredPeripherals.append(peripheral)
            print("Discovered \(peripheral.name ?? "Unknown Device")")
            self.objectWillChange.send()
        }
    }
//        if peripheral.name == "ESP32" && !discoveredPeripherals.contains(where: { $0.identifier == peripheral.identifier }) {
//                    discoveredPeripherals.append(peripheral)
//                    print("Discovered \(peripheral.name ?? "Unknown Device")")
//                    self.objectWillChange.send()
//                }
    
    
    //if connection succeeds
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheralStatus = .connected
        peripheral.delegate = self
        peripheral.discoverServices([SERVICE_UUID])
        print("Connected to \(peripheral.name ?? "Unknown Device")")
        centralManager.stopScan()
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: (any Error)?) {
        peripheralStatus = .disconnected
        espPeripheral = nil
        weightCharacteristic = nil
        levelCharacteristic = nil
        rideControlCharacteristic = nil
        calibrateCharacteristic = nil
        pendingWeight = nil
        pendingLevel = nil
        pendingRideControl = nil
        pendingCalibrationCommand = nil
        print("Disconnected from \(peripheral.name ?? "Unknown Device")")
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: (any Error)?) {
        peripheralStatus = .error
        print("Failed to connect: \(error?.localizedDescription ?? "No description")")
    }
}

extension BluetoothManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: (any Error)?) {
        if let error = error {
            print("Error discovering services: \(error.localizedDescription)")
            peripheralStatus = .error
            return
        }
        
        for service in peripheral.services ?? [] { //loop through to find data you are looking for
            if service.uuid == SERVICE_UUID {
                print("Found service for \(SERVICE_UUID)")
                peripheral.discoverCharacteristics([UUID_WEIGHT, UUID_LEVEL, UUID_CALIBRATE_CMD, UUID_SENSOR_ALERT, UUID_RIDE_CONTROL, UUID_SENSOR_DATA], for: service)
                
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: (any Error)?) {
        if let error = error {
            print("Error discovering characteristics: \(error.localizedDescription)")
            peripheralStatus = .error
            return
        }
        
        for characteristic in service.characteristics ?? [] {
            //peripheral.setNotifyValue(true, for: characteristic) //setting up listener for notify
            print("Found characteristic: \(characteristic.uuid), waiting on values.")
            if characteristic.uuid == UUID_WEIGHT {
                weightCharacteristic = characteristic
                if let weight = pendingWeight {
                    sendWeight(weight)
                    pendingWeight = nil
                }
            }else if characteristic.uuid == UUID_LEVEL {
                levelCharacteristic = characteristic
                if let level = pendingLevel {
                    sendLevel(level)
                    pendingLevel = nil
                }
            } else if characteristic.uuid == UUID_CALIBRATE_CMD{
                calibrateCharacteristic = characteristic
                if let command = pendingCalibrationCommand {
                    sendCalibrationCommand(command)
                    pendingCalibrationCommand = nil
                }
            } else if characteristic.uuid == UUID_RIDE_CONTROL{
                rideControlCharacteristic = characteristic
                if let command = pendingRideControl {
                    sendRideControl(command)
                    pendingRideControl = nil
                }
            } else if characteristic.uuid == UUID_SENSOR_DATA || characteristic.uuid == UUID_SENSOR_ALERT {
                peripheral.setNotifyValue(true, for: characteristic)
                print("Subscribed to notifications for \(characteristic.uuid)")
            }
        }
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: (any Error)?) {
        if characteristic.uuid == UUID_SENSOR_DATA || characteristic.uuid == UUID_SENSOR_ALERT {
            if let error = error {
                print("Error receiving data: \(error.localizedDescription)")
                peripheralStatus = .error
                return
            }
            guard let data = characteristic.value else {
                print("No data received for \(characteristic.uuid.uuidString)")
                return
            }
            
            if characteristic.uuid == UUID_SENSOR_DATA {
                if let data = characteristic.value {
                    do {
                        let tempReading = try JSONDecoder().decode(TempSensorReading.self, from: data)

                        //  Log raw sensor data immediately
//                        print("Incoming BLE Data — Time: \(tempReading.timestamp), Sensors: \(tempReading.sensors)")

                        if let ride = currentRide {
                            let reading = SensorReading(timestamp: tempReading.timestamp, sensors: tempReading.sensors)
                            reading.ride = ride

                            // Log before adding to buffer
//                            print("Before Append — Buffered Count: \(bufferedReadings.count)")
                            bufferedReadings.append(reading)
//                            print("After Append — Buffered Count: \(bufferedReadings.count)")
                        }
                        } catch {
                            print(" Failed to decode sensor data: \(error)")
                        }
                    
                }
                
            } else if characteristic.uuid == UUID_SENSOR_ALERT {
                if let data = characteristic.value {
                    if let array = try? JSONSerialization.jsonObject(with: data) as? [Int],
                       array.count == 2,
                       let ride = currentRide {

                        let type = array[0]
                        let intensity = array[1]
                        let timestamp = Date().timeIntervalSince(ride.startTime)  // Estimate timestamp

                        print("Parsed array alert: type=\(type), intensity=\(intensity), estimated timestamp=\(timestamp)")

                        let alert = RideAlert(timestamp: timestamp, type: type, intensity: intensity, ride: ride)
                        bufferedAlerts.append(alert)
                        
                        alertHistory.append((timestamp: Date().timeIntervalSince1970, alert: alert))
                        alertHistory = alertHistory.filter { Date().timeIntervalSince1970 - $0.timestamp <= 10 }

//                        if let alertType = AlertType(rawValue: type) {
//                            let spokenMessage = alertType.message(forIntensity: intensity)
////                            speak(message: spokenMessage, intensity: intensity)
//                            if isRideActive {
//                                    queuedAlerts.append(spokenMessage)
//                                }
//                        }
                    }
                
//                if let data = characteristic.value {
//                    do {
//                        if let jsonStr = String(data: data, encoding: .utf8) {
//                            print("📦 Incoming alert JSON: \(jsonStr)")
//                        }
//
//                        let json = try JSONSerialization.jsonObject(with: data, options: []) as? [Any]
//                        
//                        guard
//                            let timestamp = json?[0] as? Double,
//                            let alertArray = json?[1] as? [Int],
//                            alertArray.count == 2
//                        else {
//                            print("❌ Malformed alert data structure")
//                            return
//                        }
//
//                        let type = alertArray[0]
//                        let intensity = alertArray[1]
//                        
//                        print("✅ Parsed alert - timestamp: \(timestamp), type: \(type), intensity: \(intensity)")
//
//                        let alert = RideAlert(timestamp: timestamp, type: type, intensity: intensity, ride: currentRide)
//                        bufferedAlerts.append(alert)
//
//                        if let alertType = AlertType(rawValue: type) {
//                            let message = alertType.message(forIntensity: intensity)
//                            speak(message: message, intensity: intensity)
//                        }
//                    } catch {
//                        print("❌ Failed to decode RideAlert: \(error)")
//                    }

//                    do {
//                        let tempAlert = try JSONDecoder().decode(TempAlertReading.self, from: data)
//                        print("🔍 Raw incoming alert data: \(String(data: data, encoding: .utf8) ?? "Unreadable")")
//                        
//                        
//                        guard tempAlert.alert.count == 2,
//                        let ride = currentRide else {
//                            print("Alert data incorrect form or no current ride")
//                            return
//                        }
//    
//                        let type = tempAlert.alert[0]
//                        let intensity = tempAlert.alert[1]
//                        
//                        let alert = RideAlert(timestamp: tempAlert.timestamp, type: type, intensity: intensity, ride: ride)
//                        print("Before Append — Buffered Count: \(bufferedAlerts.count)")
//                        bufferedAlerts.append(alert)
//                        print("After Append — Buffered Count: \(bufferedAlerts.count)")
//                        
//                        print("Parsed alert - Type: \(type), Intensity: \(intensity), Time: \(tempAlert.timestamp)")
//                        
//                        if let alertType = AlertType(rawValue: type) {
//                            let spokenMessage = alertType.message(forIntensity: alert.intensity)
//                            speak(message: spokenMessage, intensity: alert.intensity)
//                        }
//                        
//                    }
//                    catch{
//                        print("Failed to decode RideAlert: \(error)")
//                    }
                }
            }
        }
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?){
        if let error = error {
            print("Error writing to characteristic \(characteristic.uuid): \(error.localizedDescription)")
        }
        else {
            print("Successfully wrote to characteristic \(characteristic.uuid)")
        }
    }
}

